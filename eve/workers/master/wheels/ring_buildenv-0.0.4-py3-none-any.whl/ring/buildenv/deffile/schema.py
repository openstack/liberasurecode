"""Function to validate environment definition data.

Content:

* `validate`
"""

import collections
import pathlib
import typing

import schema
import semantic_version

import ring.buildenv.deffile.exceptions as exceptions


Distribution = collections.namedtuple("Distribution", [
    "type", "name", "release", "codename", "arch"
])


class _FieldValidatable(object):
    """Base class of all \\*Validatable classes on this file.

    It's used mainly to specify the name of the field in the
    definition file to be more explicit in error messages.
    """
    def __init__(self, fieldname: str):
        """`_FieldValidatable` constructor.

        :arg fieldname: Name of the field in the definition file.
        """
        self.fieldname = fieldname


class _FilledStringValidatable(_FieldValidatable):
    """Validation class to refuse empty or missing string value."""
    def validate(self, data: typing.Any) -> str:
        """Check if the data is not None, not empty and is a string.

        :arg data: Data to check
        :raises schema.SchemaError: If the given data is not valid.
        :returns: The given data after check.
        """
        if data is None:
            raise schema.SchemaError("{0} is missing".format(self.fieldname))

        if not isinstance(data, str):
            raise schema.SchemaError(
                "{0} must be a string".format(self.fieldname)
            )

        if not data:
            raise schema.SchemaError(
                "{0} can't be empty".format(self.fieldname)
            )

        return data


class _VersionValidatable(_FilledStringValidatable):
    """Validation class to parse a version value."""
    def __init__(self, fieldname: str="version"):
        """`_VersionValidatable` constructor.

        :arg fieldname: Name of the version field in the definition file.
        """
        super().__init__(fieldname)

    def validate(self, data: typing.Any) -> semantic_version.Version:
        """Parse the given data to a ``semantic_version.Version`` object.

        :raises schema.SchemaError: If the value isn't correct.
        :returns: The computed ``semantic_version.Version`` object.
        """
        super().validate(data)

        try:
            version = semantic_version.Version(data, partial=True)
        except ValueError as exc:
            raise schema.SchemaError(
                'Incorrect "{0}": {1}'.format(self.fieldname, exc)
            )

        if version.minor is None:
            version.minor = 0

        return version


class _DistributionValidatable(_FieldValidatable):
    """Validation class to parse a distribution value."""
    def __init__(self, fieldname: str="distribution"):
        """`_DistributionValidatable` constructor.

        :arg fieldname: Name of the distribution field in the definition file.
        """
        super().__init__(fieldname)

    def validate(self, data: typing.Any) -> Distribution:
        """Check the data is a dict with right mandatory keys.

        A distribution object in the definition file is a dict with
        different mandatories fields:

        * **type**: debian or redhat string value.
        * **name**: Name of the distribution.
        * **release**: Release of the distribution.
        * **codename**: Codename of the distribution.
        * **arch**: Architecture of the distribution.

        :arg data: Data to check
        :raises schema.SchemaError: If the given data isn't correct.
        :returns: The computed `Distribution` object.
        """
        fields = {
            key: _FilledStringValidatable(
                fieldname="{0}::{1}".format(self.fieldname, key)
            ) for key in ["type", "name", "release", "codename", "arch"]
        }

        fields["type"] = schema.And(
            fields["type"], lambda value: value in ["debian", "redhat"]
        )

        data = schema.Schema(fields).validate(data)

        return Distribution(**data)


class _SortedFlattenUniqListValidatable(_FieldValidatable):
    """Check the data is a list.

    Entry of the data list can be another list.
    This class flatten the list, remove duplicated entries and sort
    the list before return it.
    """
    @staticmethod
    def _iter_elems(elems: list):
        """Iterate recursively over all entries of the given list.

        :arg elems: List of entries.
        :yield: Entry of the given list.
        """
        for elem in elems:
            if isinstance(elem, list):
                yield from _SortedFlattenUniqListValidatable._iter_elems(elem)
            else:
                yield elem

    def validate(self, data: typing.Any) -> list:
        """Validate the given data and return the list of elements.

        Entry of the given data list can be another list.
        This function flatten the list, remove duplicated entries and sort
        the list.

        :arg data: Data to check
        :raises schema.SchemaError: If the given data isn't correct.
        :returns: The computed list of elements
        """
        if data is None:
            raise schema.SchemaError("{0} is missing".format(self.fieldname))

        if not isinstance(data, list):
            raise schema.SchemaError("{0} must be a list".format(
                self.fieldname
            ))

        data = list(set(self._iter_elems(data)))
        data.sort()

        return data


def validate(filepath: pathlib.Path, data: typing.Any) -> dict:
    """Validate the given content of the ``RING`` environments defintion file.

    :arg filepath: Path of the definition file.
      It's used only for the error message.
    :arg data: Data of the definition file.

    .. note::

       This function can modify the given data.

    :raises DefFileError: If the given data are incorrect.
    :returns: The computed data
    """
    try:
        return schema.Schema({
            "version": _VersionValidatable(),
            "distribution": _DistributionValidatable(),
            schema.Optional("components", default={}): schema.Schema({
                str: _SortedFlattenUniqListValidatable("components")
            }),
            schema.Optional("environments", default={}): schema.Schema({
                str: schema.Schema({
                    "image": schema.Schema({
                        schema.Optional("from"): str,
                        "dockerfile": str,
                        schema.Optional("includes", default={}): dict
                    }),
                    "dependencies": _SortedFlattenUniqListValidatable(
                        "dependencies"
                    )
                })
            })
        }).validate(data)
    except schema.SchemaError as exc:
        raise exceptions.DefFileError(
            'The definition file "{0}" is incorrect: {1}'.format(
                filepath, exc
            )
        )
