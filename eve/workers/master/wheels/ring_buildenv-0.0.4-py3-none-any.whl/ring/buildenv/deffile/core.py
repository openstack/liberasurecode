"""RING environments definition file object.

This module provide the `DefFile` class to manipulate the
definition file which describe all ``RING`` environments and all
prerequisites.

See :ref:`ring-env-deffile` for more details on the format of this file.

Contents:

* `DefFile`: Class to manipulate a ``RING`` environments defintion file.
"""

import pathlib
import yaml

import ring.buildenv.deffile.exceptions as exceptions
import ring.buildenv.deffile.schema as schema


class DefFile(object):
    """Class to manipulate a ``RING`` environments defintion file."""
    def __init__(self):
        self.data = None

    def load(self, filepath: pathlib.Path):
        """Load the content of the ``RING`` environments definition file given.

        :args filepath: Path of the ``RING`` environments
          definition file to load
        :raises `DefFileError`_: If the definition file is incorrect
          (bad YAML format or bad schema).
        """
        try:
            with filepath.open("r") as deffile:
                data = yaml.load(deffile)
        except OSError as exc:
            raise exceptions.DefFileError(
                'Unable to read definition file "{0}": {1}'.format(
                    filepath, exc
                )
            )
        except yaml.YAMLError as exc:
            raise exceptions.DefFileError(
                'The definition file "{0}" is incorrect '
                '(bad YAML format): {1}'.format(
                    filepath, exc
                )
            )

        self.data = schema.validate(filepath, data)

    @property
    def distribution(self) -> schema.Distribution:
        """Property with the distribution object of the definition file.

        :returns: The distribution from the loaded definition file.
        """
        return self.data["distribution"]

    def get_env(self, envname) -> dict:
        """Get the RING environment section of the deffile."""
        env = self.data["environments"].get(envname, {})
        env.setdefault("name", envname)
        return env

    def get_all_packages(self) -> set:
        """Compute the list of dependencies of all ``RING`` environments.

        We remove all duplicated entries before to return the list.

        :returns: The name of all packages.
        """
        packages = set()
        for env in self.data["environments"].values():
            for pkgname in env["dependencies"]:
                if not pkgname.startswith("-"):
                    packages.add(pkgname)

        return packages

    def get_packages(self, envname: str) -> list:
        """Return the list of dependencies of the given environment."""
        return self.get_env(envname).get("dependencies", [])
