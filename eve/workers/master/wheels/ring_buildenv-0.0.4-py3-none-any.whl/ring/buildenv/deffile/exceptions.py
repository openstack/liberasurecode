"""Exceptions raised in the manipulation of a ``RING``
environments definition file."""

import ring.buildenv.exceptions as exceptions


class DefFileError(exceptions.BuildEnvException):
    """Exception raised by `~.core.DefFile` class."""
    pass
