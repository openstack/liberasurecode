"""Utilities around the tool ``reprepro``.

Reprepro is a tool to handle local repositories of debian packages.

`RepreproTool` is a class to simplify execution of ``reprepro`` with a
specific configuration.

Contents:

* `RepreproTool`: Wrapper class above the tool ``reprepro``.
* `RepreproDistributionsFile`: Object to store the content of a
  ``reprepro`` distributions file.
* `RepreproException`: Exception raised by `RepreproTool` class.
"""

import logging
import os
import re
import subprocess
import tempfile
import typing

import ring.buildenv.exceptions as exceptions


logger = logging.getLogger(__name__)


class RepreproException(exceptions.BuildEnvException):
    """Exception raised by `RepreproTool` class."""
    pass


class RepreproDistributionsFile(object):
    """Object to store the content of a ``reprepro`` distributions file."""
    def __init__(self, filepath: str=None):
        self.filepath = filepath

        self.distname = None
        self.signing_key = None

        if self.filepath is not None:
            self.load()

    def load(self, filepath: str=None):
        """Load the given ``reprepro`` distributions file.

        :args filepath: Path of the ``reprepro`` distributions file to load.
        :raises RepreproException: On error
        """
        if filepath is None:
            if self.filepath is None:
                raise RuntimeError(
                    "filepath must be given on the constructor or"
                    " on the load function"
                )
        else:
            self.filepath = filepath
        self.distname = None
        self.signing_key = None

        if not os.path.exists(self.filepath):
            raise RepreproException(
                'The configuration file "{0}" is needed to reprepro'.format(
                    self.filepath
                )
            )

        codename_regexp = re.compile(r"^Codename:\s*(?P<codename>\S+)")
        sign_with_regexp = re.compile(r"^SignWith:\s*(?P<key>\S+)")

        with open(self.filepath, "r") as dist_file:
            for line in dist_file:
                m = codename_regexp.match(line)
                if m:
                    self.distname = m.group("codename")

                m = sign_with_regexp.match(line)
                if m:
                    self.signing_key = m.group("key")

        if self.distname is None:
            raise RepreproException(
                'Unable to retrieve the codename of the repository'
            )


class RepreproTool(object):
    """Wrapper class above the tool ``reprepro``.

    ``reprepro`` binary have a lot of configuration argument, like the
    path of the configuration directory, the path of the database
    directory, ...

    This class help to create a *execution context* around this tool.
    """
    def __init__(self, cfgdir: str, dbdir: str, outputdir: str, tmpdir: str):
        """`RepreproTool` constructor

        :arg cfgdir: Path of the configuration directory of reprepro.
        :arg dbdir: Path of the reprepro database directory.
        :arg outputdir: Path of the output repository directory.
        :arg tmpdir: Path of the temporary directory.
        """
        self.cfgdir = os.path.abspath(cfgdir)
        self.dbdir = os.path.abspath(dbdir)
        self.outputdir = os.path.abspath(outputdir)
        self.tmpdir = tmpdir

        self.env = None

        self.distfile = RepreproDistributionsFile()

    def configure(self, secret_key: str=None):
        """Initialize the ``reprepro`` execution context.

        Retrieve the codename and the signing key of the output
        repository from the reprero distribution configuration file.

        ``reprepro`` haven't got an option to specify the path of the
        signing key file.
        If we want sign the repository with a external key outside the
        default keyring, we have to create a temporary GPG home
        directory.

        Finally, this function will create an empty repository.

        :arg secret_key: Path of the secret key to use.
        :raises `RepreproException`: On error
        """
        dist_filepath = os.path.join(self.cfgdir, "distributions")
        self.distfile.load(dist_filepath)

        if self.distfile.signing_key and secret_key:
            self._init_gnupg(secret_key)

        logger.info("Creating empty repository...")
        self.run("export")

    def _init_gnupg(self, secret_key: str):
        """Create a temporary GPG home directory.

        We need to import the secret key in a new GPG home directory.

        All ``reprepro`` commands will be executed with the correct
        ``GNUPGHOME`` environment variable to target this GPG home
        directory.

        :arg secret_key: Path to the secret key.
        """
        logger.info('Creating temporary gnupg home for reprepro...')

        gpg_homedir = tempfile.mkdtemp(prefix="gnupg-", dir=self.tmpdir)

        self.env = os.environ.copy()
        self.env.update({
            "GNUPGHOME": gpg_homedir
        })

        subprocess.run(["gpg", "--import", secret_key],
                       shell=False, check=True, stderr=subprocess.DEVNULL,
                       env=self.env)

    def includedeb(self, debfiles: typing.List[str]):
        """Include all given debian packages into the repository.

        Call ``reprepro`` includedeb for all given packages.

        :arg debfiles: List of debian packages file path.
        """
        for debfile in debfiles:
            logger.info('Adding "%s" to %s...',
                        os.path.basename(debfile), self.distfile.distname)

        self.run(
            "includedeb", self.distfile.distname,
            *debfiles, stdout=subprocess.PIPE
        )

    def run(self, *args, **kwargs):
        """Execute ``reprepro`` command

        :arg args: Arguments to ``reprepro`` command
        :arg kwargs: Extra arguments to `subprocess.run`
        :raises `RepreproException`: If the command fails
        """
        commandline = [
            "reprepro",
            "-b", self.tmpdir,
            "--dbdir", self.dbdir,
            "--confdir", self.cfgdir,
            "--outdir", self.outputdir
        ] + list(args)

        logger.debug("> %s", " ".join(commandline))

        result = subprocess.run(
            commandline, shell=False,
            check=False, env=self.env,
            **kwargs
        )

        if result.returncode != 0:
            raise RepreproException(
                "Unable to execute reprepro command - exitcode: {0}".format(
                    result.returncode
                )
            )

        return result
