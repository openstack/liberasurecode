"""Utilities around the tool ``repotrack``.

``repotrack`` is a tool of ``yum-utils`` but we have a optimized
version called ``scalrepotrack`` (see :ref:`ring-create-redhat-repository`).

Contents:

* `RepotrackTool`: Wrapper class above the tool ``scalrepotrack``.
"""

import logging
import os
import pathlib
import subprocess
import typing

import ring.buildenv.exceptions as exceptions


logger = logging.getLogger(__name__)


class RepotrackTool(object):
    """Wrapper class above ``scalrepotrack``."""
    def __init__(self, download_path: pathlib.Path,
                 releasever: typing.Union[None, int],
                 root: typing.Union[None, pathlib.Path]=None,
                 config_filepath: typing.Union[None, pathlib.Path]=None,
                 arch: typing.Union[None, str]=None):
        """`RepotrackTool` constructor.

        :args download_path: Path of the output directory where we
           download packages.
        :args releasever: Release version of redhat system.
        :args root: Path of the root directory (default: /).
        :args config_filepath: Path of the ``YUM`` configuration file
          (default: */etc/yum.conf*).
        :args arch: Architecture to use (default: x86_64).
        """
        self.download_path = download_path

        self.releasever = releasever
        self.root = root
        self.config_filepath = config_filepath
        self.arch = arch

    def run(self, pkgs: typing.Iterable[str]):
        """Execute ``scalrepotrack`` to download the given packages.

        :args pkgs: List of packages to download.
        :raises BuildEnvException: On error.
        """
        commandline = ["scalrepotrack"]
        if self.releasever:
            commandline += ["--releasever", str(self.releasever)]
        if self.root:
            commandline += ["--root", str(self.root)]
        if self.config_filepath:
            commandline += ["--config", str(self.config_filepath)]
        if self.arch:
            commandline += ["--arch", self.arch]

        commandline += [
            "--download_path", str(self.download_path)
        ] + list(pkgs)

        logger.debug("> %s", " ".join(commandline))

        env = os.environ.copy()
        env.update({
            "LC_ALL": "en_US.UTF-8",
            "LANG": "en_US.UTF-8",
            "LANGUAGE": "en_US",
        })

        result = subprocess.run(commandline, shell=False,
                                check=False, env=env)

        if result.returncode != 0:
            raise exceptions.BuildEnvException(
                'Fail to download all needed packages (exitcode: {0})'.format(
                    result.returncode
                )
            )
