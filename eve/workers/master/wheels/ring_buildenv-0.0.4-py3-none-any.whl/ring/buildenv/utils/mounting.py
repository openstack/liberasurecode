"""Utilities around filesystem mount points

Contents:

* `MountPoint`: Mount temporary a file system attachement.
* `SystemMountPoints`: Mount all needed system mountpoints.
* :meth:`mount`
* :meth:`umount`
* `Flags`: List mount flags.
* `MountError`: Exception raised in :meth:`mount` call.
* `UmountError`: Exception raised in :meth:`umount` call.
"""

import contextlib
import ctypes
import ctypes.util
import enum
import logging
import os
import pathlib
import typing

import ring.buildenv.exceptions as exceptions

logger = logging.getLogger(__name__)

__libc__ = ctypes.CDLL(
    ctypes.util.find_library("c"),
    use_errno=True
)


class Flags(enum.IntEnum):
    """Mount flags extracted from */usr/include/linux/fs.h*

    .. seealso::

       `mount(2) <http://man7.org/linux/man-pages/man2/mount.2.html>`_
    """
    MS_RDONLY = 1
    """Mount file system read-only."""

    MS_NOSUID = 1 << 0
    """Do not honor set-user-ID and set-group-ID bits when executing
    programs from this file system."""

    MS_NODEV = 1 << 2
    """Do not allow access to devices (special files) on this file system."""

    MS_NOEXEC = 1 << 3
    """Do not allow programs to be executed from this file system."""

    MS_SYNC = MS_SYNCHRONOUS = 1 << 4
    """Make writes on this file system synchronous (as though the
    O_SYNC flag to open(2) was specified for all file opens to this
    file system)."""

    MS_REMOUNT = 1 << 5
    """Remount an existing mount. This allows you to change the
    mountflags and data of an existing mount without having to unmount
    and remount the file system. target should be the same value
    specified in the initial mount() call; source and filesystemtype
    are ignored."""

    MS_MANDLOCK = 1 << 6
    """Permit mandatory locking on files in this file
    system. (Mandatory locking must still be enabled on a per-file
    basis, as described in fcntl(2).)"""

    MS_DIRSYNC = 1 << 7
    """Make directory changes on this file system synchronous. (This
    property can be obtained for individual directories or subtrees
    using chattr(1).)"""

    MS_NOATIME = 1 << 10
    """Do not update access times for (all types of) files on this
    file system."""

    MS_NODIRATIME = 1 << 11
    """Do not update access times for directories on this file
    system. This flag provides a subset of the functionality provided
    by MS_NOATIME; that is, MS_NOATIME implies MS_NODIRATIME."""

    MS_BIND = 1 << 12
    """Perform a bind mount, making a file or a directory subtree
    visible at another point within a file system. Bind mounts may
    cross file system boundaries and span chroot(2) jails."""

    MS_MOVE = 1 << 13
    """Move a subtree. source specifies an existing mount point and
    target specifies the new location."""

    MS_REC = 1 << 14
    """Used in conjunction with MS_BIND to create a recursive bind
    mount, and in conjunction with the propagation type
    flags to recursively change the propagation type of all
    of the mounts in a subtree."""

    MS_SILENT = MS_VERBOSE = 1 << 15
    """Suppress the display of certain (printk()) warning messages in
    the kernel log."""

    MS_POSIXACL = 1 << 16

    MS_UNBINDABLE = 1 << 17
    """Make this mount unbindable."""

    MS_PRIVATE = 1 << 18
    """Make this mount point private."""

    MS_SLAVE = 1 << 19
    """If this is a shared mount point that is a member of a peer
    group that contains other members, convert it to a slave mount."""

    MS_SHARED = 1 << 20
    """Make this mount point shared."""

    MS_RELATIME = 1 << 21
    """When a file on this filesystem is accessed, update the file's
    last access time (atime) only if the current value of atime is
    less than or equal to the file's last modification time (mtime) or
    last status change time (ctime)."""

    MS_KERNMOUNT = 1 << 22
    MS_I_VERSION = 1 << 23

    MS_STRICTATIME = 1 << 24
    """Always update the last access time (atime) when files on this
    file system are accessed."""

    MS_LAZYTIME = 1 << 25
    """Reduce on-disk updates of inode timestamps (atime, mtime,
    ctime) by maintaining these changes only in memory."""

    MS_RMT_MASK = \
        MS_RDONLY | MS_SYNCHRONOUS | MS_MANDLOCK | MS_I_VERSION | MS_LAZYTIME
    """Superblock flags that can be altered by MS_REMOUNT."""

    MS_MGC_VAL = 0xC0ED0000
    """Old magic mount flag."""

    MS_MGC_MSK = 0xffff0000
    """Old magic mount mask."""


def __char_p(value: typing.Union[None, str, pathlib.Path],
             encoding="utf-8"):
    if value is None:
        return None
    elif isinstance(value, pathlib.Path):
        return bytes(value)
    else:
        return value.encode(encoding)


def mount(source: typing.Union[None, str, pathlib.Path],
          target: typing.Union[None, str, pathlib.Path],
          fstype: typing.Union[None, str],
          flags: int=Flags.MS_RDONLY,
          fs_options: str=None):
    """Call `mount()`_ of libc.

    Attaches the file system specified by source (which is often a
    device name, but can also be a directory name or a dummy) to the
    directory specified by target.

    :args source: Source filesystem path.
    :args target: Target filesystem path.
    :args fstype: Filesystem type

    All filesystems type supported are listed in **/proc/filesystems**.

    :args flags: Mount flags.
    :args fs_options: String of comma-separated options understood by
                        this file system.
    :raises MountError: On error

    .. _mount(): http://man7.org/linux/man-pages/man2/mount.2.html
    """
    result = __libc__.mount(
        ctypes.c_char_p(__char_p(source)),
        ctypes.c_char_p(__char_p(target)),
        ctypes.c_char_p(__char_p(fstype)),
        flags,
        ctypes.c_char_p(fs_options) if fs_options is not None else 0
    )

    if result != 0:
        raise MountError(source, target)


def umount(target: typing.Union[None, str, pathlib.Path]):
    """Call `umount()`_ of libc.

    Remove the attachment of the (topmost) filesystem mounted on target.

    :args target: Filesystem path
    :raises UmountError: On error

    .. _umount(): http://man7.org/linux/man-pages/man2/umount2.2.html
    """
    result = __libc__.umount(
        ctypes.c_char_p(__char_p(target))
    )

    if result != 0:
        raise UmountError(target)


class MountPoint(object):
    """Class to mount temporary a file system attachement."""
    def __init__(self,
                 source: typing.Union[None, pathlib.Path],
                 target: typing.Union[None, pathlib.Path],
                 fstype: typing.Union[None, typing.AnyStr],
                 flags: int=Flags.MS_RDONLY,
                 fs_options: str=None):
        """`MountPoint` constructor.

        Usage::

           import subprocess

           import ring.buildenv.utils.mounting as mounting


           with MountPoint("/dev", "/tmp/foo/dev",
                           flags=mounting.Flags.MS_BIND):
              subprocess.run(["ls", "/tmp/foo/dev"])

        See `mount` for all arguments.

        :raises BuildEnvException: On error during the mount call.

        If *target* doesn't exists, create the directory.
        If *umount* fails, log warning.
        """
        self.source = source
        self.target = target
        self.fstype = fstype
        self.flags = flags
        self.fs_options = fs_options

    def __enter__(self):
        if not self.target.is_dir():
            try:
                self.target.mkdir(parents=True)
            except OSError as exc:
                raise exceptions.BuildEnvException(
                    'Unable to create directory "{0}": {1}'.format(
                        self.target, exc.strerror or exc
                    )
                )

        try:
            mount(self.source, self.target, self.fstype,
                  flags=self.flags,
                  fs_options=self.fs_options)
        except MountError as exc:
            raise exceptions.BuildEnvException(
                'Unable to mount "{0}" to "{1}": {2}'.format(
                    self.source, self.target, exc.strerror or exc
                )
            )

        return self

    def __exit__(self, exc_type, exc_value, traceback):
        try:
            umount(self.target)
        except UmountError as exc:
            logger.warning('Unable to umount "%s": %s',
                           self.target, exc.strerror or exc)


@contextlib.contextmanager
def SystemMountPoints(rootdirpath: typing.Union[
        typing.AnyStr, pathlib.Path
]):  # pylint: disable=invalid-name
    """Mount temporary all needed system mountpoints.

    Usage::

        import subprocess

        import ring.buildenv.utils.mounting as mounting


        with mounting.system_mountpoints("/tmp/foo"):
           subprocess.run(["mount"])

    .. code-block:: text

        ...
        none on /tmp/foo/proc type proc (rw,relatime)
        udev on /tmp/foo/dev type devtmpfs (rw,nosuid,relatime,...)
        none on /tmp/foo/sys type sysfs (rw,relatime)
    """
    if not isinstance(rootdirpath, pathlib.Path):
        rootdirpath = pathlib.Path(rootdirpath)

    localrootdirpath = pathlib.Path("/")

    system_mountpoints_table = [
        MountPoint(
            None,
            rootdirpath.joinpath("proc"),
            "proc"
        ),
        MountPoint(
            localrootdirpath.joinpath("dev"),
            rootdirpath.joinpath("dev"),
            None,
            flags=Flags.MS_BIND
        ),
        MountPoint(
            None,
            rootdirpath.joinpath("sys"),
            "sysfs"
        ),
    ]

    with contextlib.ExitStack() as stack:
        for system_mountpoint in system_mountpoints_table:
            stack.enter_context(system_mountpoint)

        yield


class MountError(OSError):
    """Exception raised by `mount`."""
    def __init__(self, source, target):
        """`MountError` constructor.

        :args source: Source directory
        :args target: Target directory
        """
        self.source = source
        self.target = target

        errno = ctypes.get_errno()
        message = 'mount("{0}", "{1}")'.format(
            self.source if self.source else "",
            self.target if self.source else ""
        )

        super(MountError, self).__init__(
            errno, os.strerror(errno), message
        )


class UmountError(OSError):
    """Exception raised by `umount`."""
    def __init__(self, target):
        """`UmountError` constructor.

        :args target: Target directory
        """
        self.target = target

        errno = ctypes.get_errno()
        message = "{0}".format(self.target)

        super(UmountError, self).__init__(
            errno, os.strerror(errno), message
        )
