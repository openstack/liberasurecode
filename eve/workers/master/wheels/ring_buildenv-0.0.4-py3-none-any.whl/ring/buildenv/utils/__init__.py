"""Miscellaneous utility functions and classes.

This module is used internally by ``ring.buildenv``.
"""

import contextlib
import logging
import pathlib
import re
import shutil
import string
import sys
import typing

import ring.buildenv.exceptions as exceptions

logger = logging.getLogger(__name__)


class BatchRun(object):
    """Run a callback per batch of elements.

    Call the :meth:`run` method to fill the pool of elements and
    run the callback given when the pool is full, and start over.

    .. doctest::

        >>> import ring.buildenv.utils as utils
        >>> with utils.BatchRun(print, 3) as batch:
        ...     for idx in range(7):
        ...         print("pass before")
        ...         batch.run("Hello {0}".format(idx))
        ...         print("pass after")
        pass before
        pass after
        pass before
        pass after
        pass before
        ['Hello 0', 'Hello 1', 'Hello 2']
        pass after
        pass before
        pass after
        pass before
        pass after
        pass before
        ['Hello 3', 'Hello 4', 'Hello 5']
        pass after
        pass before
        pass after
        ['Hello 6']
    """
    def __init__(self, cb: typing.Callable[[typing.Any], None],
                 batch_size: int=50):
        """`BatchRun` constructor.

        :arg cb: Function to run.
        :arg batch_size: Size of the pool of entries.
        """
        self.cb = cb
        self.batch_size = batch_size

        self.entries = None

    def run(self, entry: typing.Any):
        """Add element in the pool.

        If the pool is full, run the callback for all elements saved
        and clear the pool.
        """
        self.entries.append(entry)
        if len(self.entries) >= self.batch_size:
            self.cb(self.entries)
            self.entries.clear()

    def __enter__(self):
        self.entries = []
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if not exc_value:
            if self.entries:
                self.cb(self.entries)
                self.entries.clear()

        self.entries = None


def render_template_file(srcfilepath: pathlib.Path,
                         destfilepath: pathlib.Path,
                         data: dict) -> None:
    """Generate file from a template file.

    :args srcfilepath: Path of the template file.
    :args destfilepath: Path of the output file.
    :args data: Data to interpolate in the template file.
    :raises BuildEnvException: On error
    """
    try:
        with srcfilepath.open("r") as srcfile:
            content = srcfile.read()
    except OSError as exc:
        raise exceptions.BuildEnvException(
            'Unable to read the file "{0}": {1}'.format(
                srcfilepath, exc.strerror or exc
            )
        )

    template = string.Template(content)
    try:
        new_content = template.substitute({
            k: str(v) for k, v in data.items()
        })
    except ValueError as exc:
        raise exceptions.BuildEnvException(
            'Invalid template file "{0}": {1}'.format(
                srcfilepath, exc
            )
        )
    except KeyError as exc:
        raise exceptions.BuildEnvException(
            'Invalid template file "{0}":'
            ' Unable to find placeholder "{1}"'.format(
                srcfilepath, exc.args[0]
            )
        )

    try:
        with destfilepath.open("w") as destfile:
            destfile.write(new_content)
    except OSError as exc:
        raise exceptions.BuildEnvException(
            'Unable to write the file "{0}": {1}'.format(
                destfilepath, exc.strerror or exc
            )
        )


def iter_pkgname(pkgs: typing.List[str],
                 pkglist_filepath: typing.Union[None, pathlib.Path]=None):
    """Iterate over all packages name given.

    We have two ways to pass a list of package name:

    * From a list
    * From a file containing a list of packages name.

    This function yield for each package name given in ``pkgs`` and
    for each line of the file given in ``pkglist_filepath`` (excluding
    empty line and line beginning by **#**).

    :args pkgs: List of packages name.
    :args pkglist_filepath: Path of the file containing a list of package name.

    if ``pkglist_filepath`` is the special value ``-``, we use the
    standard input.

    :yield: A debian package name
    """
    for pkgname in pkgs:
        yield pkgname

    if not pkglist_filepath:
        return

    comment_or_emptyline_regexp = re.compile(r"^\s*(?:#|$)")

    if str(pkglist_filepath) == '-':
        pkglist = sys.stdin
    else:
        pkglist = pkglist_filepath.open("r")

    try:
        for line in pkglist:
            if comment_or_emptyline_regexp.match(line):
                continue

            yield line.strip()
    finally:
        if pkglist_filepath != '-':
            pkglist.close()


@contextlib.contextmanager
def use_temporary_file_copy(srcfilepath: pathlib.Path,
                            destfilepath: pathlib.Path):
    """Use a ephemeral copy of a file.

    :args srcfilepath: Path of the file to copy.
    :args destfilepath: Path of the file to write.
    """
    try:
        shutil.copy2(str(srcfilepath), str(destfilepath))
    except OSError as exc:
        raise exceptions.BuildEnvException(
            'Unable to copy the file "{0}" to "{1}": {2}'.format(
                srcfilepath, destfilepath, exc.strerror or exc
            )
        )

    try:
        yield destfilepath
    finally:
        try:
            destfilepath.unlink()
        except OSError as exc:
            logger.warning('Unable to remove "%s": %s',
                           destfilepath, exc.strerror or exc)
