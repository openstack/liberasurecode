import pkg_resources


try:
    # pylint: disable=no-member
    __version__ = pkg_resources.get_distribution(__name__).version
except pkg_resources.DistributionNotFound:
    __version__ = None
