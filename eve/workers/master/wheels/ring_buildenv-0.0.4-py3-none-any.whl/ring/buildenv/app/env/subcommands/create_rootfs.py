"""``create-rootfs`` subcommand of :ref:`ring-env`.

Content:

* `CreateRootfsSubCommand`
"""

import argparse
import logging
import os

import ring.buildenv.app.env.context as app_context
from ring.buildenv.app.env.subcommands import BaseSubCommand
import ring.buildenv.exceptions as exceptions


logger = logging.getLogger(__name__)


class CreateRootfsSubCommand(BaseSubCommand):
    """Create the rootfs of the distribution."""

    command = 'create-rootfs'

    aliases = ['crfs']
    """Alias of the subcommand in :ref:`ring-env`."""

    def init_parser(self, subparser: argparse.ArgumentParser) -> None:
        """Init argument of *create-rootfs* sub application.

        :args subparser: Subparser created by
                :meth:`~ring.buildenv.app.env.main.RingEnvApp.init_parser`
        """
        subparser.add_argument(
            "-f", "--force", action="store_true", default=False,
            help="Force the bootstrap of the system (invalid the cache)"
        )

    def run(self, envctx: app_context.RingEnvCtx):
        """Called by the *create-rootfs* subcommand.

        :raises BuildEnvException: On error
        """
        if envctx.deffile.distribution.type == "debian":
            cmdline = [
                "ring-create-debian-rootfs",
                "--suite", envctx.deffile.distribution.codename,
                "--arch", envctx.deffile.distribution.arch,
            ]
        elif envctx.deffile.distribution.type == "redhat":
            cmdline = [
                "ring-create-redhat-rootfs",
                "--releasepkg", "{0}-release".format(
                    envctx.deffile.distribution.name
                )
            ]
        else:
            raise exceptions.BuildEnvException(
                "{0} distribution not supported yet".format(
                    envctx.deffile.distribution.type
                )
            )

        cmdline += ["--output", envctx.data.rootfs]

        for pkgname in envctx.deffile.get_packages("base"):
            if pkgname.startswith('?'):
                continue

            if pkgname.startswith('-'):
                cmdline += ["-X", pkgname[1:]]
            else:
                cmdline += ["-I", pkgname]

        cmdline += [
            "--format", envctx.data.rootfs_format,
        ]

        postinstall_script_filepath = os.path.join(
            envctx.data.rootfs_cfgdir, "postinstall.sh"
        )

        if os.path.exists(postinstall_script_filepath) and \
           os.access(postinstall_script_filepath, os.X_OK):
            cmdline += [
                "--postinstall", postinstall_script_filepath
            ]

        if envctx.data.rootfs_cachedir:
            cmdline += ["--cachedir", envctx.data.rootfs_cachedir]

        cmdline += [
            "--mirror", "file://{0}".format(
                os.path.abspath(envctx.data.repository)
            )
        ]

        if envctx.data.public_key:
            cmdline += ["--public-key", envctx.data.public_key]

        if self.args.force:
            cmdline += ["--force"]
        else:
            cmdline += ["--force-overwrite"]

        if self.args.debug:
            cmdline += ["--debug"]

        if os.getuid() != 0:
            logger.warning(
                "Warning: Command not executed as root, use sudo "
                "to execute '%s'", cmdline[0]
            )
            cmdline.insert(0, "sudo")

        logger.debug("> %s", " ".join(cmdline))

        try:
            self.subprocess(cmdline, shell=False)
        except exceptions.ShellCommandError:
            raise exceptions.BuildEnvException(
                "Unable to create the rootfs archive"
            )

        return 0
