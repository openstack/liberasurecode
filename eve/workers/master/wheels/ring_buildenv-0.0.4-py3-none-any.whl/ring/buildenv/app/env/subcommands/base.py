"""Base class of all :ref:`ring-env` subcommand classes.

Content:

* `BaseSubCommand`
"""

import abc
import argparse
import weakref

import ring.buildenv.app.env.context as app_context


class BaseSubCommand(object, metaclass=abc.ABCMeta):
    """Base class of all :ref:`ring-env` subcommand classes."""

    command = None
    """Name of the subcommand"""

    aliases = []
    """List of aliases of the subcommand"""

    def __init__(self, app):
        """*BaseSubCommand* constructor.

        :args app: `~.main.RingEnvApp` object

        We store a weak reference of this object.
        """
        self.app = weakref.proxy(app)

    def init_parser(self, subparser: argparse.ArgumentParser) -> None:
        """Initialize the subparser.

        Used to add extra arguments.

        :args subparser: Subparser to configure
        """
        pass

    @abc.abstractmethod
    def run(self, envctx: app_context.RingEnvCtx):
        """Main function called by the parser."""
        pass

    def post_parse_arguments(self):
        """Called after the parsing of arguments."""
        pass

    def __getattr__(self, attrname: str):
        return getattr(self.app, attrname)
