"""``create-repository`` subcommand of :ref:`ring-env`.

Content:

* `CreateRepositorySubCommand`
"""

import ring.buildenv.app.env.context as app_context
from ring.buildenv.app.env.subcommands import BaseSubCommand
import ring.buildenv.exceptions as exceptions


class CreateRepositorySubCommand(BaseSubCommand):
    """Create the local repository."""

    command = 'create-repository'

    aliases = ['cr']
    """Alias of the subcommand in :ref:`ring-env`."""

    def run(self, envctx: app_context.RingEnvCtx):
        """Called by the *create-repository* subcommand.

        :raises BuildEnvException: On error
        """
        if envctx.deffile.distribution.type == "debian":
            script_name = "ring-create-debian-repository"
        elif envctx.deffile.distribution.type == "redhat":
            script_name = "ring-create-redhat-repository"
        else:
            raise exceptions.BuildEnvException(
                'Distribution type "{0}" not supported'.format(
                    envctx.deffile.distribution.type
                )
            )

        args = [
            script_name,
            "--cfgdir", envctx.data.repository_cfgdir
        ]

        if envctx.deffile.distribution.type == "redhat":
            if envctx.data.sign_date:
                args += ["--sign-date", envctx.data.sign_date]

        args += [
            "-P", "-"
        ]

        if envctx.deffile.distribution.type == "redhat":
            args += [
                "--arch", envctx.deffile.distribution.arch,
                "--releasever", envctx.deffile.distribution.release,
            ]

        if envctx.data.private_key:
            args += ["--secret-key", envctx.data.private_key]

        if envctx.data.repository_cachedir:
            args += ["--cachedir", envctx.data.repository_cachedir]

        if self.args.debug:
            args += ["--debug"]

        args += [envctx.data.repository]

        input_data = "\n".join(
            envctx.deffile.get_all_packages()
        ) + "\n"

        try:
            self.subprocess(args, input=input_data.encode("utf-8"))
        except exceptions.ShellCommandError:
            raise exceptions.BuildEnvException(
                "Unable to create the local repository"
            )
