"""Environment execution context data for :ref:`ring-env` application.

`RingEnvCtxData` is an object to give more accessible data related
of the :ref:`ring-env` application configuration with the environment
execution context (see `~.context.RingEnvCtx`).

Content:

* `RingEnvCtxData`
"""

import os
import string
import weakref

import ring.buildenv.exceptions as exceptions


class RingEnvCtxData(object):
    """Data used by `~.main.RingEnvApp`.

    Make available all computed data from the ``RING`` environements
    definition file and from the `~.main.RingEnvApp` configuration file.

    This class is used as a namespace data volume to simplify the
    share of variables between the differents subcommands of
    :ref:`ring-env`.

    This class is also used to substitute variables inside a string
    template (see :meth:`substitute`).
    """
    def __init__(self, ctx):
        """`RingEnvCtxData` constructor.

        :args ctx: `~.context.RingEnvCtx` object
        """
        self.ctx = weakref.proxy(ctx)

    @property
    def distname(self):
        """Return the {name}-{codename} of the distribution given.

        E.g. ubuntu-trusty, centos-final, ...
        """
        return "{0}-{1}".format(
            self.ctx.deffile.distribution.name,
            self.ctx.deffile.distribution.codename
        )

    @property
    def rootfs(self):
        """Return the path of the rootfs for the given distribution.

        E.g. ubuntu-trusty-amd64-rootfs.tar.gz
        """
        format_to_extfile = {
            "gzip": "tar.gz",
            "bzip2": "tar.bz",
            "lzma": "tar.xz"
        }
        output_fileext = format_to_extfile.get(self.rootfs_format, "tar")
        output_filename = "{0}-{1}-rootfs.{2}".format(
            self.distname,
            self.ctx.deffile.distribution.arch,
            output_fileext
        )

        return os.path.join(
            self.ctx.config["rootfs"]["output_dirpath"],
            output_filename
        )

    @property
    def rootfs_cfgdir(self):
        """Return the path of the rootfs configuration directory."""
        return os.path.join(
            self.ctx.config["rootfs"]["cfgdir"],
            self.distname
        )

    @property
    def rootfs_cachedir(self):
        """Return the path of cache directory used for rootfs."""
        return os.path.join(
            self.ctx.config["rootfs"].get("cachedir"),
            self.distname
        )

    @property
    def rootfs_format(self):
        """Return the format of the rootfs archive."""
        return self.ctx.config["rootfs"].get("format", "gzip")

    @property
    def repository(self):
        """Return the path of the repository for the given distribution."""
        return os.path.join(
            self.ctx.config["repository"]["output_dirpath"],
            self.distname
        )

    @property
    def repository_cfgdir(self):
        """Return the path of the repository configuration directory."""
        return os.path.join(
            self.ctx.config["repository"]["cfgdir"],
            self.distname
        )

    @property
    def repository_cachedir(self):
        """Return the path of the repository cache directory."""
        return os.path.join(
            self.ctx.config["repository"].get("cachedir"),
            self.distname
        )

    @property
    def docker_dirpath(self):
        """Return the path of the directory containing the ``Dockerile``."""
        return self.ctx.config["docker"]["dirpath"]

    @property
    def public_key(self):
        """Return the path of the public key."""
        return self.ctx.config["gpg"].get("public_key")

    @property
    def private_key(self):
        """Return the path of the private key."""
        return self.ctx.config["gpg"].get("private_key")

    @property
    def sign_date(self):
        """Return the signing date."""
        return self.ctx.config["repository"].get("sign_date")

    def substitute(self, data: str, envname: str):
        """Substitute all variable content in the given string.

        This method is used by
        `~.subcommands.create_docker_image.CreateDockerImageSubCommand`
        subcommand.

        Example::

          >>> app.data.substitute(
          ...   "${docker_dirpath}/${distname}/${envname}/Dockerfile"
          ... )
          'docker/ubuntu-trusty/build/Dockerfile

        :args data: String to substitute variables value.
        :args envname: Override the name of the environment.
        :raises BuildEnvException: If a variable can't be sustituted.
        """
        list_methods = list(filter(
            lambda x: not x.startswith('_') and x not in [
                'substitute'
            ],
            dir(self.__class__)
        ))

        ctx = {
            meth: getattr(self, meth) for meth in list_methods
        }
        ctx["envname"] = envname

        tpl = string.Template(data)

        try:
            return tpl.substitute(ctx)
        except KeyError as exc:
            raise exceptions.BuildEnvException(
                'Incorrect value "{0}": {1} can\'t be sustituted'.format(
                    data, exc
                )
            )
