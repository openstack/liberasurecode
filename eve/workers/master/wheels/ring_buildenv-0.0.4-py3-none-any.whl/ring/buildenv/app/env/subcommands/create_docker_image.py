"""``create-docker-image`` subcommand of :ref:`ring-env`.

Content:

* `CreateDockerImageSubCommand`
"""

import argparse
import logging
import os
import tempfile
import typing

import ring.buildenv.app.env.context as app_context
from ring.buildenv.app.env.subcommands import BaseSubCommand
import ring.buildenv.exceptions as exceptions


logger = logging.getLogger(__name__)


class CreateDockerImageSubCommand(BaseSubCommand):
    """Create a Docker image."""

    command = 'create-docker-image'

    aliases = ['cdi']
    """Alias of the subcommand in :ref:`ring-env`."""

    def init_parser(self, subparser: argparse.ArgumentParser) -> None:
        """Init arguments of *create-docker-image* subcommand.

        :args subparser: Subparser created by
                :meth:`~ring.buildenv.app.env.main.RingEnvApp.init_parser`
        """
        subparser.add_argument(
            "-e", "--env", dest="envname", required=True,
            help="RING environement name (eg, base, build)"
        )
        subparser.add_argument(
            "--no-tag-inter", dest="tag_intermediate_images",
            action="store_false", default="true",
            help="Don't tag intermediate Docker images"
        )

        docker_tag_group = subparser.add_mutually_exclusive_group()
        docker_tag_group.add_argument(
            "-t", "--tag", dest="tags", action="append", default=[],
            help="Tag the Docker image"
        )
        docker_tag_group.add_argument(
            "--no-tag", dest="tags", action="store_const", const=None,
            help="Don't tag the Docker image"
        )

        subparser.add_argument(
            "--from", dest="from_image", metavar="IMAGE_ID",
            nargs='?', const=':auto:',
            help="Override FROM instruction in the dockerfile to use"
            "the given image id (use :auto: to compute the FROM"
            "instruction from the definition file"
        )
        subparser.add_argument(
            "--print-image-id-to-fd", dest="output_image_id_fd",
            type=int, metavar="FD",
            help="File descriptor to print the if of the image buid"
        )

    def run(self, envctx: app_context.RingEnvCtx):
        """Called by the *create-docker-image* subcommand.

        :raises BuildEnvException: On error
        """
        env = envctx.deffile.get_env(self.args.envname)

        if self.args.from_image:
            from_image = self.args.from_image
            if from_image == ':auto:':
                from_env_name = env["image"].get("from")
                if not from_env_name:
                    raise exceptions.BuildEnvException(
                        'The environment "{0}" is not dependent'
                        ' on another environment'.format(
                            env["name"]
                        )
                    )

                from_image = "{0}/{1}:{2}-{3}".format(
                    self.app.config["docker"]["repository"],
                    from_env_name,
                    envctx.deffile.distribution.name,
                    envctx.deffile.distribution.codename
                )
        else:
            from_envs = []

            from_env = env
            while from_env is not None:
                from_env_name = from_env["image"].get("from")
                if from_env_name:
                    from_env = envctx.deffile.get_env(from_env_name)
                    from_envs.append(from_env)
                else:
                    from_env = None

            from_image = None
            for from_env in reversed(from_envs):
                if self.args.tags is not None:
                    if self.args.tag_intermediate_images:
                        tags = []
                    else:
                        tags = None
                else:
                    tags = None

                from_image = self.__create_docker_image(
                    from_env, envctx, tags, from_image
                )

        image_id = self.__create_docker_image(
            env, envctx, self.args.tags, from_image
        )

        if self.args.output_image_id_fd is not None:
            with os.fdopen(self.args.output_image_id_fd, "w") as output_file:
                output_file.write("{0}\n".format(image_id))
                output_file.flush()

    def __create_docker_image(self, env: dict,
                              envctx: app_context.RingEnvCtx,
                              tags: typing.List[str]=None,
                              from_image: str=None) -> str:
        """Called by the *create-docker-image* subcommand.

        :raises BuildEnvException: On error
        """
        logger.info('Creating Docker image for "%s" environment...',
                    env["name"])

        args = ["ring-create-docker-image"]

        if self.args.debug:
            args += ["--debug"]

        args += [
            "-f", envctx.data.substitute(
                env["image"]["dockerfile"], env["name"]
            )
        ]

        for raw_key, value in env["image"]["includes"].items():
            key = envctx.data.substitute(raw_key, env["name"])
            if value:
                include_value = "{0}={1}".format(key, value)
            else:
                include_value = key
            args += ["-I", include_value]

        if from_image:
            args += ["--from", from_image]

        if tags is not None:
            if not tags:
                tags += [
                    "{0}/{1}:{2}-{3}".format(
                        self.app.config["docker"]["repository"],
                        env["name"],
                        envctx.deffile.distribution.name,
                        envctx.deffile.distribution.codename
                    )
                ]

            for tag in tags:
                args += ["--tag", tag]

        output_image_id_file = tempfile.NamedTemporaryFile(
            prefix="print_image_id-", mode="w+"
        )
        output_image_id_fd = output_image_id_file.fileno()
        args += [
            "--print-image-id-to-fd", str(output_image_id_fd)
        ]

        logger.debug('Executing "%s"...', " ".join(args))
        try:
            self.subprocess(args, pass_fds=[output_image_id_fd])
        except exceptions.ShellCommandError:
            raise exceptions.BuildEnvException(
                "Unable to create the docker image"
            )

        output_image_id_file.seek(0)
        output_image_id_content = output_image_id_file.read()

        logger.debug('Content print on FD %d: "%s"',
                     output_image_id_fd,
                     output_image_id_content)

        try:
            return output_image_id_content.splitlines()[0]
        except (TypeError, IndexError) as exc:
            raise exceptions.BuildEnvException(
                "Unable to get image id: {0}".format(exc)
            )
