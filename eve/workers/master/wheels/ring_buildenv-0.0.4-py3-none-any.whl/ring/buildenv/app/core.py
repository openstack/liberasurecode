"""Application base class.

Each script of ``ring.buildenv`` is an `Application` object.
"""

import abc
import argparse
import logging
import typing

import ring.buildenv
import ring.buildenv.exceptions as exceptions


logger = logging.getLogger(__name__)


class Application(metaclass=abc.ABCMeta):
    """Base class of all ``ring.buildenv`` applications.

    .. doctest::

        >>> import argparse
        >>> import ring.buildenv.app.core as app_core

        >>> class MyApplication(app_core.Application):
        ...     def init_parser(self):
        ...         self.parser = argparse.ArgumentParser(
        ...             self.name, add_help=False
        ...         )
        ...         self.parser.add_argument("-c", dest="foo",
        ...                                  type=int, default=0)
        ...         super().init_parser()
        ...
        ...     def run(self):
        ...         print("OK")
        ...
        ...     def clean(self):
        ...         print("CLEAN")

        >>> def test(args):
        ...     with MyApplication("foo", args) as current_app:
        ...         return current_app.run() or 0
        ...     return 1 # Exception raised

        >>> test([])
        OK
        CLEAN
        0

        >>> test(["--unknown-arg"])
        Traceback (most recent call last):
        ...
        SystemExit: 2
    """

    app_exception = exceptions.BuildEnvException
    """Base exception of all exceptions raised by the application"""

    app_logger = logging.getLogger(ring.buildenv.__name__)
    """Root logger used by the application"""

    def __init__(self, name: typing.AnyStr=None,
                 args: typing.Sequence[typing.AnyStr]=None):
        """`Application` constructor

        :arg name: Name of the application (used by argparse)
        :arg args: Arguments list of the application (sys.argv by default)
        """
        self.name = name
        self.input_args = args

        self.parser = None
        self.args = None

    def _init_logging(self):
        """Initialize the logger used by the application."""
        formatter = logging.Formatter("%(message)s")

        handler = logging.StreamHandler()
        handler.setFormatter(formatter)

        while self.app_logger.hasHandlers():
            self.app_logger.removeHandler(self.app_logger.handlers[0])
        self.app_logger.addHandler(handler)

        if self.args.debug:
            log_lvl = logging.DEBUG
        else:
            log_lvl = logging.INFO
        self.app_logger.setLevel(log_lvl)

    def init_parser(self):
        """Initialize the parser of the application.

        Overload this method to add arguments.
        """
        self.parser = argparse.ArgumentParser(self.name, add_help=False)

        generic_group = self.parser.add_argument_group("generic options")
        generic_group.add_argument(
            "-d", "--debug", action="store_true", default=False,
            help="Show debug messages"
        )
        generic_group.add_argument(
            "-h", "--help", action="help",
            help="Show this help message and exit"
        )

    def init(self):
        """Initialize the application.

        The main goal is to parse arguments and configure the logger.
        """
        self.init_parser()
        self.args = self.parser.parse_args(self.input_args)

        self._init_logging()

    @abc.abstractmethod
    def run(self):
        """Main function of the application.

        If this function raise an `app_exception` exception,
        log the message as critic and exit the application.

        :return: Application exit code.
        :return 0 or None: On success.
        :return != 0: On failure.
        """
        raise NotImplementedError()

    def clean(self):
        """Cleanup the application."""
        pass

    def __enter__(self):
        self.init()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.clean()
        if exc_value and isinstance(exc_value, self.app_exception):
            self.app_logger.critical("%s", exc_value)
            return True
