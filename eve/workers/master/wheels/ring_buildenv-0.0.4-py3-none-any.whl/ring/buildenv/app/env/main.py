"""Core of the :ref:`ring-env` application.

Contents:

* `RingEnvApp`: Application class
* `main`: Main function called by :ref:`ring-env`
"""

import argparse
import configparser
import logging
import os
import pathlib
import typing

import ring.buildenv.app.core as app_core
import ring.buildenv.app.env.context as app_context
import ring.buildenv.app.env.mixins as app_mixins
import ring.buildenv.app.env.subcommands as app_subcommands
import ring.buildenv.exceptions as exceptions


logger = logging.getLogger(__name__)


class RingEnvApp(app_mixins.ShellCommandMixin,
                 app_core.Application):
    """`~.core.Application` class.

    This class is the core of the application :ref:`ring-env`.

    Usage (called by :func:`main`)::

        with RingEnvApp() as current_app:
          return current_app.run() or 0
        return 1
    """
    subcommand_classes = [
        app_subcommands.CreateRepositorySubCommand,
        app_subcommands.CreateRootfsSubCommand,
        app_subcommands.CreateDockerImageSubCommand,
        app_subcommands.CleanSubCommand,
    ]
    """List all subcommand classes to instantiate."""

    def __init__(self, *args, **kwargs):
        """`RingEnvApp` constructor.

        :arg args: `~.core.Application` args.
        :arg kwargs: `~.core.Application` kwargs.
        """
        super().__init__(*args, **kwargs)

        self.config = configparser.ConfigParser(
            interpolation=configparser.ExtendedInterpolation()
        )

    def init_parser(self) -> None:
        """Add all arguments to the application.

        See :ref:`ring-env-usage`.
        """
        common_parser = argparse.ArgumentParser(add_help=False)

        generic_group = common_parser.add_argument_group('generic options')
        generic_group.add_argument(
            '-h', '--help', action='help',
            help='Show this help message and exit'
        )
        generic_group.add_argument(
            'envnames', nargs='*', metavar='ENV',
            help='Target environments (e.g. ubuntu-trusty, centos-final, ...)'
        )

        self.parser = argparse.ArgumentParser(self.name, add_help=False)

        main_group = self.parser.add_argument_group('options')
        main_group.add_argument(
            '-c', '--config', type=pathlib.Path,
            default=os.getenv("BUILDENV_CONFIG"),
            metavar='FILEPATH', dest='config_filepath',
            help='Path of the configuration file of ring-env'
        )
        main_group.add_argument(
            '-d', '--debug', action='store_true', default=False,
            help='Show debug messages'
        )
        main_group.add_argument(
            '-h', '--help', action='help',
            help='Show this help message and exit'
        )

        if not self.subcommand_classes:
            return

        subparsers = self.parser.add_subparsers(
            metavar='ACTION', dest='action'
        )
        subparsers.required = True

        for subcommand_cls in self.subcommand_classes:
            subcommand = subcommand_cls(self)
            subparser = subparsers.add_parser(
                subcommand.command, aliases=subcommand.aliases,
                help=subcommand.__doc__,
                add_help=False, parents=[common_parser]
            )
            subparser.set_defaults(subcommand=subcommand)
            subcommand.init_parser(subparser)

    def load_config(self):
        """Load the configuration file.

        :raises BuildEnvException: On error
        """
        if not self.args.config_filepath.exists():
            raise exceptions.BuildEnvException(
                'Unable to find the configuration'
                ' file "{0}"'.format(self.args.config_filepath)
            )

        self.config.read(str(self.args.config_filepath))

    def iter_environments(self):
        """Iterate over all given environments.

        Check if all given environment names are available and create
        and load a `~.context.RingEnvCtx` object for each of them.

        :raises BuildEnvException: On error
        :yield: Environment context object
        """
        deffiles_dirpath = pathlib.Path(
            self.config['root']['deffiles_dirpath']
        )

        if not deffiles_dirpath.is_dir():
            raise exceptions.BuildEnvException(
                'Unable to find the definition files'
                ' directory "{0}"'.format(
                    deffiles_dirpath
                )
            )

        available_envnames = {}
        for deffile_filepath in deffiles_dirpath.glob("*.yaml"):
            envname = deffile_filepath.stem
            available_envnames[envname] = deffile_filepath

        if not available_envnames:
            logger.info("No available environment found.")
            return

        if not self.args.envnames:
            envnames = available_envnames.items()
        else:
            envnames = []
            for envname in self.args.envnames:
                if envname in [envname[0] for envname in envnames]:
                    continue

                if envname not in available_envnames:
                    raise exceptions.BuildEnvException(
                        'Environment "{0}" not available'
                        ' (must be a value among {1})'.format(
                            envname, ', '.join([
                                "'{0}'".format(envname)
                                for envname in available_envnames
                            ])
                        )
                    )

                envnames.append(
                    (envname, available_envnames[envname])
                )

        for envname, deffile_filepath in envnames:
            ctx = app_context.RingEnvCtx(self, envname)
            ctx.load(deffile_filepath)
            yield ctx

    def run(self) -> typing.Union[None, int]:
        """Main function of the application."""
        if not self.args.config_filepath:
            self.parser.error('-c/--config argument required')
        self.args.subcommand.post_parse_arguments()

        self.load_config()

        for envctx in self.iter_environments():
            self.args.subcommand.run(envctx)

        return 0


def main() -> int:
    """Main function called by :ref:`ring-env`.

    Instantiate a `RingEnvApp` object and run it.

    See `~.core.Application` for more details.

    :returns 0: On success
    :returns != 0: On failure
    """
    with RingEnvApp() as app:
        return app.run() or 0
    return 1
