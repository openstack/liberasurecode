"""Core of the :ref:`ring-create-redhat-repository` application.

This application create a partial Redhat repository with all packages
given.

Contents:

* `CreateRedhatRepositoryApp`: Application class
* `main`: Main function called by :ref:`ring-create-redhat-repository`
"""

import argparse
import logging
import os
import pathlib
import shutil
import subprocess
import tempfile
import typing

import ring.buildenv.app.core as app_core
import ring.buildenv.exceptions as exceptions
import ring.buildenv.tools.repotrack as repotrack
import ring.buildenv.utils as utils


logger = logging.getLogger(__name__)


class CreateRedhatRepositoryApp(app_core.Application):
    """`~.core.Application` class.

    This class is the core of the application
    :ref:`ring-create-redhat-repository`.
    This application makes it possible to create a local redhat repository.

    Usage (called by :func:`main`)::

        with CreateRedhatRepositoryApp() as app:
          return app.run() or 0
        return 1
    """
    yum_etc_dirpath = "etc"
    """Path of the **etc** directory in the ``YUM`` context."""

    yum_vars_dirpath = os.path.join(yum_etc_dirpath, "yum/vars")
    """Path of the **vars** directory in the ``YUM`` context."""

    yum_cache_dirpath = "var/cache/yum"
    """Path of the **cache** directory in the ``YUM`` context.."""

    yum_persist_dirpath = "var/lib/yum"
    """Path of the **persist** directory in the ``YUM`` context.."""

    yum_logs_dirpath = "var/logs"
    """Path of the **logs** directory in the ``YUM`` context."""

    def __init__(self, *args, **kwargs):
        """`CreateRedhatRepositoryApp` constructor.

        :arg args: `~.core.Application` args.
        :arg kwargs: `~.core.Application` kwargs.
        """
        super().__init__(*args, **kwargs)

        self.tmpdir = None
        self.configdir = None

        self.gpg_key = None
        self.gpg_env = None

    def init_parser(self) -> None:
        """Add all arguments to the application.

        See :ref:`ring-create-redhat-repository-usage`.
        """
        self.parser = argparse.ArgumentParser(self.name, add_help=False)

        configuration_group = self.parser.add_argument_group(
            title="configuration options"
        )
        configuration_group.add_argument(
            "-c", "--cfgdir", type=pathlib.Path,
            help="Path of the configuration directory"
        )
        configuration_group.add_argument(
            "--sign-date",
            help="Override the sign date (default: current date)"
        )

        package_selection_group = self.parser.add_argument_group(
            title="package selection options",
            description="Options to select packages to " +
            "include in the target repository"
        )
        package_selection_group.add_argument(
            "-p", "--pkg", metavar="PKGNAME",
            dest="pkgs", action="append", default=[],
            help="Package to include"
        )
        package_selection_group.add_argument(
            "-P", "--pkglist", dest="pkglist_filepath",
            metavar="FILEPATH", type=pathlib.Path,
            help="Path of the packages list file"
        )

        other_group = self.parser.add_argument_group(
            title="other options"
        )
        other_group.add_argument(
            "-a", "--arch", default="x86_64",
            help="Target architecture"
        )
        other_group.add_argument(
            "--releasever", type=int,
            help="Release version"
        )
        other_group.add_argument(
            "--secret-key", type=pathlib.Path,
            help="Path of the secret key to use to sign the repository"
        )
        other_group.add_argument(
            "--cachedir", type=pathlib.Path,
            help="Path of the persistent cache directory to use"
        )
        other_group.add_argument(
            "output_dirpath", metavar="OUTPUT_DIRPATH", type=pathlib.Path,
            help="Path of the output repository"
        )

        generic_group = self.parser.add_argument_group("generic options")
        generic_group.add_argument(
            "-d", "--debug", action="store_true", default=False,
            help="Show debug messages"
        )
        generic_group.add_argument(
            "-h", "--help", action="help",
            help="Show this help message and exit"
        )

    def _iter_pkgname(self):
        """Iterate over all debian packages name given to the application.

        We have two ways to pass a list of package name:

        * **-p|--pkg** *<NAME>*: Give a package name.
          Can be called several times.
        * **-P|--pkglist** *<FILEPATH>*: Give a path of a file containing
          a list of packages name.

        This function yield for each package name given by the
        **-p|--pkg** option, and for each line of the file given by
        the **-P|--pkglist** option (excluding empty line and line
        beginning by **#**).

        :yield: A debian package name
        """
        yield from utils.iter_pkgname(
            self.args.pkgs,
            self.args.pkglist_filepath
        )

    def run(self) -> typing.Union[None, int]:
        """Main function of the application.

        This function will:

        * Build ``YUM`` context directory inside the temporary directory.
        * Use ``scalrepotrack`` to download all needed packages.
        * Use ``rpm`` to sign all packages.
        * Use ``createrepo`` to create the repository.
        * Use ``gpg`` to sign repository metadata.
        """
        self.tmpdir = pathlib.Path(tempfile.mkdtemp(prefix="redhat-configdir-",
                                                    suffix=".d"))
        logger.debug("Temporary directory: %s", self.tmpdir)

        self._create_cache_directory()
        self._create_etc_directory()
        self._download_packages(self.args.output_dirpath)

        if self.args.secret_key:
            self._init_gnupg(self.args.secret_key)
            self._sign_packages(self.args.output_dirpath,
                                self.args.sign_date)

        self._create_repository(self.args.output_dirpath)

    def _create_repository(self, dirpath: pathlib.Path):
        """Create RPM repository.

        ;args dirpath: Path of the directory containing RPM packages.
        :raises BuildEnvException: On error
        """
        logger.info("Generating the repository...")

        args = [
            "createrepo", "--no-database", str(dirpath)
        ]

        result = subprocess.run(args, shell=False, check=False,
                                universal_newlines=True,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)

        if result.returncode != 0:
            logger.error(result.stdout)
            raise exceptions.BuildEnvException(
                'Unable to generate the repository (exitcode: {0})'.format(
                    result.returncode
                )
            )

        if not self.args.secret_key:
            return

        logger.info("Signing repository metadata...")

        env = os.environ.copy()
        env.update(self.gpg_env)

        args = [
            "gpg",
            "--local-user", self.gpg_key,
            "--batch", "--yes",
            "--detach-sign", "--armor",
            str(dirpath.joinpath("repodata/repomd.xml"))
        ]

        result = subprocess.run(args, shell=False, check=False, env=env)

        if result.returncode != 0:
            raise exceptions.BuildEnvException(
                'Unable to sign repository metadata (exitcode: {0})'.format(
                    result.returncode
                )
            )

    def _sign_packages(self, dirpath: pathlib.Path,
                       sign_date: typing.Union[None, str],
                       batch_size: int=30):
        """Sign all packages with the given secret key.

        RPM will store the current date in the metadata of the package.
        To make this output package deterministic, we need to override
        the system time.

        :args dirpath: Path of the directory containing RPM packages
                         to sign.
        :args sign_date: Change the system time to this value.
        :args batch_size: Number of packages max to pass to rpm per batch.
        :raises BuildEnvException: On error
        """
        env = os.environ.copy()
        env.update(self.gpg_env)

        list_packages = list(dirpath.glob("*.rpm"))

        logger.info("Signing %d packages...", len(list_packages))

        for idx in range(0, len(list_packages), batch_size):
            sublist_packages = [
                str(pkg) for pkg in list_packages[idx:idx + batch_size]
            ]

            for pkgpath in sublist_packages:
                logger.info("    %s", pkgpath)

            args = []

            if sign_date:
                args += ["faketime", "-f", sign_date]

            args += [
                "rpm", "--resign", "-D", "_gpg_name {0}".format(self.gpg_key)
            ] + sublist_packages

            result = subprocess.run(args, shell=False, check=False, env=env,
                                    universal_newlines=True,
                                    stdin=subprocess.DEVNULL,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT,
                                    preexec_fn=os.setsid)

            if result.returncode != 0:
                logger.error(result.stdout)
                raise exceptions.BuildEnvException(
                    'Unable to sign packages (exitcode: {0})'.format(
                        result.returncode
                    )
                )

    def _init_gnupg(self, secret_key: pathlib.Path):
        """Create a temporary GPG home directory.

        We need to import the secret key in a new GPG home directory.

        :arg secret_key: Path to the secret key file.
        :raises BuildEnvException: On error
        """
        logger.info('Creating temporary gnupg home...')

        gpg_homedir = tempfile.mkdtemp(prefix="gnupg-", dir=str(self.tmpdir))

        self.gpg_env = {
            "GNUPGHOME": gpg_homedir
        }

        env = os.environ.copy()
        env.update(self.gpg_env)

        result = subprocess.run(["gpg", "--import", str(secret_key)],
                                shell=False, check=False,
                                stderr=subprocess.DEVNULL, env=env)

        if result.returncode != 0:
            raise exceptions.BuildEnvException(
                'Unable to import GPG secret key (exitcode: {0})'.format(
                    result.returncode
                )
            )

        result = subprocess.run(["gpg", "--with-colon", "-K"],
                                shell=False, check=True,
                                universal_newlines=True,
                                stdout=subprocess.PIPE, env=env)

        if result.returncode != 0:
            raise exceptions.BuildEnvException(
                'Unable to list GPG secret keys (exitcode: {0})'.format(
                    result.returncode
                )
            )

        for line in result.stdout.splitlines():
            parts = line.split(':')
            if parts[0] == 'sec':
                self.gpg_key = parts[4]
                break

        if not self.gpg_key:
            raise exceptions.BuildEnvException(
                'Unable to find the GPG key fingerprint'
            )

        logger.debug("GPG key: %s", self.gpg_key)

    def _create_cache_directory(self) -> None:
        """Create the cache directory in the ``YUM`` context.

        If we give a specific cache directory path, we need to create
        the symbolic link to this directory inside the ``YUM``
        context.

        :raises BuildEnvException: On error
        """
        fullcachedirpath = self.tmpdir.joinpath(self.yum_cache_dirpath)
        fullpersistdirpath = self.tmpdir.joinpath(self.yum_persist_dirpath)

        if self.args.cachedir:
            destcachedirpath = self.args.cachedir.joinpath("cache")
            destpersistdirpath = self.args.cachedir.joinpath("lib")

            for dirpath in [fullcachedirpath.parent,
                            fullpersistdirpath.parent,
                            destcachedirpath,
                            destpersistdirpath]:
                try:
                    dirpath.mkdir(mode=0o755, parents=True, exist_ok=True)
                except OSError as exc:
                    raise exceptions.BuildEnvException(
                        'Unable to directory "{0}": {1}'.format(
                            dirpath, exc.strerror or exc
                        )
                    )

            links = [
                (fullcachedirpath, destcachedirpath),
                (fullpersistdirpath, destpersistdirpath)
            ]

            for srcdirpath, destdirpath in links:
                try:
                    srcdirpath.symlink_to(destdirpath)
                except OSError as exc:
                    raise exceptions.BuildEnvException(
                        'Unable to create the symbolic link "{0}": {1}'.format(
                            srcdirpath, exc.strerror or exc
                        )
                    )
        else:
            for dirpath in [fullcachedirpath, fullpersistdirpath]:
                try:
                    dirpath.mkdir(mode=0o755, parents=True)
                except OSError as exc:
                    raise exceptions.BuildEnvException(
                        'Unable to directory "{0}": {1}'.format(
                            dirpath, exc.strerror or exc
                        )
                    )

    def _create_etc_directory(self) -> None:
        """Create the **etc** directory in the ``YUM`` context.

        We create a symbolic link with all files in the given config
        directory path.
        We fill also the /etc/yum/vars directory (see
        :meth:`_generate_vars_directory`).

        :raises BuildEnvException: On error
        """
        fulletcdirpath = self.tmpdir.joinpath(self.yum_etc_dirpath)
        rootdirpath = pathlib.Path("/")

        def onerror(exc):
            raise exceptions.BuildEnvException(
                'Unable to list files of the directory "{0}": {1}'.format(
                    exc.filename, exc.strerror or exc
                )
            )

        for root, _, filenames in os.walk(str(self.args.cfgdir),
                                          onerror=onerror):
            root = pathlib.Path(root)
            reldirpath = root.relative_to(self.args.cfgdir)
            destdir = fulletcdirpath.joinpath(reldirpath)
            if not destdir.is_dir():
                try:
                    destdir.mkdir()
                except OSError as exc:
                    raise exceptions.BuildEnvException(
                        'Unable to create the directory "{0}": {1}'.format(
                            destdir, exc.strerror or exc
                        )
                    )

            for filename in filenames:
                srcfilepath = root.joinpath(filename)
                destfilepath = destdir.joinpath(filename)

                utils.render_template_file(srcfilepath, destfilepath, {
                    "cachedir": rootdirpath.joinpath(self.yum_cache_dirpath),
                    "persistdir": rootdirpath.joinpath(
                        self.yum_persist_dirpath
                    ),
                    "logsdir": rootdirpath.joinpath(self.yum_logs_dirpath),
                    "etcdir": fulletcdirpath,
                    "tmpdir": self.tmpdir,
                })

        self._generate_vars_directory(self.yum_vars_dirpath, {
            "etcdirpath": fulletcdirpath,
            "infra": "container",
        })

    def _generate_vars_directory(self, dirpath: str, yum_vars: dict) -> None:
        """Fill the **/etc/yum/vars/** directory inside the ``YUM`` context.

        :args dirpath: Subpath of the directory inside the ``YUM`` context.
        :args yum_vars: Dict with all ``YUM`` vars.
        :raises BuildEnvException: On Error
        """
        fulldirpath = self.tmpdir.joinpath(dirpath)
        if not fulldirpath.is_dir():
            try:
                fulldirpath.mkdir(mode=0o755, parents=True)
            except OSError as exc:
                raise exceptions.BuildEnvException(
                    'Unable to create "{0}": {1}'.format(
                        fulldirpath, exc.strerror or exc
                    )
                )

        for yum_varname, value in yum_vars.items():
            var_filepath = fulldirpath.joinpath(yum_varname)
            logger.debug('Creating "%s" with the content "%s"...',
                         var_filepath, value)
            try:
                with var_filepath.open("w") as var_file:
                    var_file.write("{0}\n".format(value))
            except OSError as exc:
                raise exceptions.BuildEnvException(
                    'Unable to create the file "{0}": {1}'.format(
                        var_filepath, exc.strerror or exc
                    )
                )

    def _download_packages(self, dirpath: pathlib.Path) -> None:
        """Run ``scalrepotrack`` to download all needed packages.

        :args dirpath: Path of the directory to download packages.
        :raises BuildEnvException: On error
        """
        fulletcdirpath = self.tmpdir.joinpath(self.yum_etc_dirpath)

        yum_config_filename = "yum.conf"
        yum_config_filepath = fulletcdirpath.joinpath(yum_config_filename)
        if not yum_config_filepath.exists:
            raise exceptions.BuildEnvException(
                'Missing configuration file "{0}"'.format(
                    self.args.cfgdir.joinpath(yum_config_filename)
                )
            )

        args = {
            'releasever': self.args.releasever,
            'root': self.tmpdir,
            'config_filepath': yum_config_filepath,
            'arch': self.args.arch
        }
        pkgs = self._iter_pkgname()

        repotrack.RepotrackTool(dirpath, **args).run(pkgs)

    def clean(self):
        """Remove the temporary directory."""
        if not self.tmpdir:
            return

        try:
            shutil.rmtree(str(self.tmpdir))
        except OSError as exc:
            logger.warning(
                'Unable to remove temporary directory "%s": %s',
                self.tmpdir, exc
            )


def main() -> int:
    """Main function called by :ref:`ring-create-redhat-repository`.

    Instantiate a `CreateRedhatRepositoryApp` object and run it.

    See `~.core.Application` for more details.

    :returns 0: On success
    :returns != 0: On failure
    """
    with CreateRedhatRepositoryApp() as app:
        return app.run() or 0
    return 1
