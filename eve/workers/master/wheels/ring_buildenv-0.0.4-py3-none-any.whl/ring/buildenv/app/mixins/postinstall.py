"""Mixin class to execute postinstall script on chroot environment.

Contents:

* `PostinstallAppMixin`: Mixin class to provide
  :meth:`~PostinstallAppMixin._init_postinstall_parser` and
  :meth:`~PostinstallAppMixin._execute_postinstall_script` methods.
"""

import contextlib
import logging
import os
import pathlib
import subprocess

import ring.buildenv.exceptions as exceptions
import ring.buildenv.utils as utils
import ring.buildenv.utils.mounting as mounting

logger = logging.getLogger(__name__)


class PostinstallAppMixin(object):
    def _init_postinstall_parser(self) -> None:
        """Add postinstall options to the parser."""
        postinstall_group = self.parser.add_argument_group(
            "postinstall options"
        )
        postinstall_group.add_argument(
            "--postinstall", dest="postinstall_script_filepath",
            type=pathlib.Path,
            help="Path of the postinstall script to execute"
        )

    def _execute_postinstall_script(self, dirpath: pathlib.Path) -> None:
        """Execute the postinsatll script from the given directory path.

        :args dirpath: Path of the root directory of the system.
        :raises BuildEnvException: On error.
        """
        if not self.args.postinstall_script_filepath:
            return

        logger.info('Executing "%s" from chroot "%s"...',
                    self.args.postinstall_script_filepath,
                    dirpath)

        with contextlib.ExitStack() as stack:
            postinstall_script_filepath = stack.enter_context(
                utils.use_temporary_file_copy(
                    self.args.postinstall_script_filepath,
                    dirpath.joinpath("tmp", "postinstall.sh")
                )
            )
            stack.enter_context(mounting.SystemMountPoints(dirpath))

            cmdline = [str(
                postinstall_script_filepath.relative_to(dirpath)
            )]

            def preexec_fn():
                os.chroot(str(dirpath))
                os.chdir("/")

            env = {
                "SHELL": "/bin/bash",
                "TERM": os.getenv("TERM", ""),
                "USER": "root",
                "PATH": ":".join([
                    "/usr/local/sbin",
                    "/usr/local/bin",
                    "/usr/sbin",
                    "/usr/bin",
                    "/sbin",
                    "/bin",
                ]),
                "LANG": os.getenv("LANG", ""),
                "HOME": "/root",
            }

            try:
                subprocess.run(
                    cmdline, preexec_fn=preexec_fn,
                    shell=False, check=True, env=env,
                    universal_newlines=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT
                )
            except FileNotFoundError:
                raise exceptions.BuildEnvException(
                    'Unable to find the postinstall script "{0}"'
                    ' in the chrooted environement'.format(cmdline[0])
                )
            except subprocess.CalledProcessError as exc:
                for line in str(exc.stdout).splitlines():
                    logger.error("%s", line)

                raise exceptions.BuildEnvException(
                    'Unable to execute the postinstall'
                    ' script (exitcode: {0})'.format(
                        exc.returncode
                    )
                )
