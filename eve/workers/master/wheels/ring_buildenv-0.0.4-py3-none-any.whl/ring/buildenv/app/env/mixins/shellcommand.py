"""Spawn process utilities for run :ref:`ring-env` subcommand."""

import logging
import subprocess

import ring.buildenv.exceptions as exceptions


logger = logging.getLogger(__name__)


class ShellCommandMixin(object):
    """Mixin class to provide subprocess method."""
    @staticmethod
    def subprocess(*args, **kwargs):
        """Spawn a process.

        :raises ShellCommandError: If the process exit with a code
           different to 0.
        """
        kwargs["check"] = True

        try:
            return subprocess.run(*args, **kwargs)
        except subprocess.CalledProcessError as exc:
            raise exceptions.ShellCommandError(
                exc.returncode,
                None, None, None
            )
