"""Core of the :ref:`ring-create-debian-repository` application.

This application create a partial Debian repository with all packages
given.

Contents:

* `CreateDebianRepositoryApp`: Application class
* `main`: Main function called by :ref:`ring-create-debian-repository`
"""

import argparse
import logging
import os
import pathlib
import shutil
import tempfile
import typing

import ring.buildenv.app.core as app_core
import ring.buildenv.tools.apt as apt
import ring.buildenv.tools.reprepro as reprepro
import ring.buildenv.utils as utils


logger = logging.getLogger(__name__)


class CreateDebianRepositoryApp(app_core.Application):
    """`~.core.Application` class.

    This class is the core of the application
    :ref:`ring-create-debian-repository`.
    This application makes it possible to create a local debian repository.

    Usage (called by :func:`main`)::

        with CreateDebianRepositoryApp() as app:
          return app.run() or 0
        return 1
    """
    def __init__(self, *args, **kwargs):
        """`CreateDebianRepositoryApp` constructor.

        :arg args: `~.core.Application` args.
        :arg kwargs: `~.core.Application` kwargs.
        """
        super().__init__(*args, **kwargs)

        self.tmpdir = None

        self.config = None
        self.reprepro = None
        self.apt = None

        self.distname = None
        self.key = None

    def init_parser(self) -> None:
        """Add all arguments to the application.

        See :ref:`ring-create-debian-repository-usage`.
        """
        self.parser = argparse.ArgumentParser(self.name, add_help=False)

        configuration_group = self.parser.add_argument_group(
            title="configuration options"
        )
        configuration_group.add_argument(
            "-c", "--cfgdir",
            help="Path of the configuration directory"
        )
        configuration_group.add_argument(
            "--reprepro-cfgdir",
            help="Path of the reprepro configuration directory " +
            "(default: <cfgdir>/reprepro)"
        )
        configuration_group.add_argument(
            "--apt-cfgdir",
            help="Path of the APT configuration directory " +
            "(default: <cfgdir>/apt)"
        )

        package_selection_group = self.parser.add_argument_group(
            title="package selection options",
            description="Options to select packages to " +
            "include in the target repository"
        )
        package_selection_group.add_argument(
            "-p", "--pkg", metavar="PKGNAME",
            dest="pkgs", action="append", default=[],
            help="Package to include"
        )
        package_selection_group.add_argument(
            "-P", "--pkglist", dest="pkglist_filepath",
            metavar="FILEPATH", type=pathlib.Path,
            help="Path of the packages list file"
        )

        other_group = self.parser.add_argument_group(
            title="other options"
        )
        other_group.add_argument(
            "--secret-key",
            help="Path of the secret key to use to sign the repository"
        )
        other_group.add_argument(
            "--cachedir",
            help="Path of the persistent cache directory to use"
        )
        other_group.add_argument(
            "output_dirpath", metavar="OUTPUT_DIRPATH",
            help="Path of the output repository"
        )

        generic_group = self.parser.add_argument_group("generic options")
        generic_group.add_argument(
            "-d", "--debug", action="store_true", default=False,
            help="Show debug messages"
        )
        generic_group.add_argument(
            "-h", "--help", action="help",
            help="Show this help message and exit"
        )

    def _iter_pkgname(self):
        """Iterate over all debian packages name given to the application.

        We have two ways to pass a list of package name:

        * **-p|--pkg** *<NAME>*: Give a package name.
          Can be called several times.
        * **-P|--pkglist** *<FILEPATH>*: Give a path of a file containing
          a list of packages name.

        This function yield for each package name given by the
        **-p|--pkg** option, and for each line of the file given by
        the **-P|--pkglist** option (excluding empty line and line
        beginning by **#**).

        :yield: A debian package name
        """
        yield from utils.iter_pkgname(
            self.args.pkgs,
            self.args.pkglist_filepath
        )

    def run(self) -> typing.Union[None, int]:
        """Main function of the application.

        This function do:

        * Check argument options (**--reprepro-cfgdir** and
          **--apt-cfgdir** are needed if **--cfgdir** is not used).
        * Create a temporary directory to store all residual files
          created by apt and reprepro.
        * Instantiate `~.apt.AptCache` object to:

           * Read remote repositories cache
           * Mark for install all needed packages
           * Fetch all packages
        * Instantiate `~.reprepro.RepreproTool` to generate the final
          repository.
        """
        if not self.args.cfgdir:
            if not self.args.reprepro_cfgdir:
                self.parser.error(
                    "You must pass --cfgdir or --reprepro-cfgdir option"
                )

            if not self.args.apt_cfgdir:
                self.parser.error(
                    "You must pass --cfgdir or --apt-cfgdir option"
                )
        else:
            if not self.args.reprepro_cfgdir:
                self.args.reprepro_cfgdir = os.path.join(
                    self.args.cfgdir, "reprepro"
                )

            if not self.args.apt_cfgdir:
                self.args.apt_cfgdir = os.path.join(
                    self.args.cfgdir, "apt"
                )

        self.tmpdir = tempfile.mkdtemp(prefix="get-deps-", suffix=".d")
        logger.debug("Temporary directory: %s", self.tmpdir)

        if not self.args.cachedir:
            self.args.cachedir = self.tmpdir

        self.apt = apt.AptCache(
            self.args.apt_cfgdir,
            self.args.cachedir,
            self.tmpdir
        )
        self.apt.configure()
        self.apt.update()

        for pkgname in self._iter_pkgname():
            self.apt.install(pkgname)

        self.apt.dump()
        self.apt.fetch()

        self.reprepro = reprepro.RepreproTool(
            self.args.reprepro_cfgdir,
            os.path.join(self.tmpdir, "dbdir"),
            self.args.output_dirpath,
            self.tmpdir
        )
        self.reprepro.configure(self.args.secret_key)

        with utils.BatchRun(self.reprepro.includedeb, 50) as batch:
            for debfile in self.apt.walk_archives():
                batch.run(debfile)

    def clean(self):
        """Remove the temporary directory."""
        if not self.tmpdir:
            return

        try:
            shutil.rmtree(self.tmpdir)
        except OSError as exc:
            logger.warning(
                'Unable to remove temporary directory "%s": %s',
                self.tmpdir, exc
            )


def main() -> int:
    """Main function called by :ref:`ring-create-debian-repository`.

    Instantiate a `CreateDebianRepositoryApp` object and run it.

    See `~.core.Application` for more details.

    :returns 0: On success
    :returns != 0: On failure
    """
    with CreateDebianRepositoryApp() as app:
        return app.run() or 0
    return 1
