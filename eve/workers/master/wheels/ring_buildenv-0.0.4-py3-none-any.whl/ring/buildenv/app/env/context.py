"""Environment execution context for :ref:`ring-env` application.

:ref:`ring-env` execute an action for multiple given environments, it
needs an execution context for each environment.

`RingEnvCtx` isolate data for this specific environment.

Content:

* `RingEnvCtx`
"""

import weakref

import ring.buildenv.app.env.data
import ring.buildenv.deffile.core


class RingEnvCtx(object):
    def __init__(self, app, envname):
        self.app = weakref.proxy(app)
        self.envname = envname

        self.deffile = ring.buildenv.deffile.core.DefFile()
        self.data = ring.buildenv.app.env.data.RingEnvCtxData(self)

    @property
    def config(self):
        return self.app.config

    def load(self, filepath):
        self.deffile.load(filepath)
