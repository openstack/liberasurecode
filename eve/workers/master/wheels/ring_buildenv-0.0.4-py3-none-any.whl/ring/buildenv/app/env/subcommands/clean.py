"""``clean`` subcommand of :ref:`ring-env`.

Content:

* `CleanSubCommand`
"""

import argparse
import logging
import os
import shutil

import ring.buildenv.app.env.context as app_context
from ring.buildenv.app.env.subcommands import BaseSubCommand

logger = logging.getLogger(__name__)


class CleanSubCommand(BaseSubCommand):
    """Clean persistent data and cache."""

    command = 'clean'

    def init_parser(self, subparser: argparse.ArgumentParser) -> None:
        """Initialize the subparser.

        Used to add extra arguments.

        :args subparser: Subparser to configure
        """
        subparser.add_argument(
            "--repository", dest="clean_repository",
            action="store_true", default=False,
            help="Clean local repository"
        )
        subparser.add_argument(
            "--rootfs", dest="clean_rootfs",
            action="store_true", default=False,
            help="Clean rootfs archive"
        )
        subparser.add_argument(
            "--data", dest="clean_data",
            action="store_true", default=True,
            help="Same as using --repository and --rootfs"
        )

        subparser.add_argument(
            "--repository-cache", dest="clean_repository_cache",
            action="store_true", default=False,
            help="Clean local repository cache"
        )
        subparser.add_argument(
            "--rootfs-cache", dest="clean_rootfs_cache",
            action="store_true", default=False,
            help="Clean rootfs archive cache"
        )
        subparser.add_argument(
            "--cache", dest="clean_cache",
            action="store_true", default=False,
            help="Same as using --repository-cache and --rootfs-cache"
        )

        subparser.add_argument(
            "--all", dest="clean_all",
            action="store_true", default=False,
            help="Same as using --data and --cache"
        )

    def post_parse_arguments(self):
        """Called after the parsing of arguments."""
        if self.args.clean_all:
            self.args.clean_data = True
            self.args.clean_cache = True

        del self.args.clean_all

        if self.args.clean_data:
            self.args.clean_repository = True
            self.args.clean_rootfs = True

        del self.args.clean_data

        if self.args.clean_cache:
            self.args.clean_repository_cache = True
            self.args.clean_rootfs_cache = True

        del self.args.clean_cache

    def run(self, envctx: app_context.RingEnvCtx):
        """Called by the *clean* subcommand.

        :raises BuildEnvException: On error
        """
        def onerror(_, path, excinfo):
            _, exc, _ = excinfo
            logger.warning('Unable to remove "%s": %s',
                           path, exc.strerror or exc)

        if self.args.clean_repository:
            if os.path.isdir(envctx.data.repository):
                logger.info('Removing "%s"...', envctx.data.repository)
                shutil.rmtree(envctx.data.repository, onerror=onerror)

        if self.args.clean_rootfs:
            if os.path.isfile(envctx.data.rootfs):
                logger.info('Removing "%s"...', envctx.data.rootfs)
                try:
                    os.unlink(envctx.data.rootfs)
                except OSError as exc:
                    logger.warning('Unable to remove "%s": %s',
                                   envctx.data.rootfs, exc)

        if self.args.clean_repository_cache:
            if os.path.isdir(envctx.data.repository_cachedir):
                logger.info('Removing "%s"...',
                            envctx.data.repository_cachedir)
                shutil.rmtree(envctx.data.repository_cachedir, onerror=onerror)

        if self.args.clean_rootfs_cache:
            if os.path.isdir(envctx.data.rootfs_cachedir):
                logger.info('Removing "%s"...',
                            envctx.data.rootfs_cachedir)
                shutil.rmtree(envctx.data.rootfs_cachedir, onerror=onerror)
