"""Core of the :ref:`ring-create-redhat-rootfs` application.

This application create a rootfs archive of redhat distribution from
the local repository created by :ref:`ring-create-redhat-repository`.

Contents:

* `CreateRedhatRootfsApp`: Application class
* `main`: Main function called by :ref:`ring-create-redhat-rootfs`
"""

import argparse
import contextlib
import logging
import os
import pathlib
import shutil
import subprocess
import tempfile
import typing

import ring.buildenv.app.core as app_core
import ring.buildenv.app.mixins as mixins
import ring.buildenv.exceptions as exceptions

logger = logging.getLogger(__name__)


class CreateRedhatRootfsApp(mixins.ArchiveAppMixin,
                            mixins.PostinstallAppMixin,
                            app_core.Application):
    """`~.core.Application` class.

    This class is the core of the application :ref:`ring-create-redhat-rootfs`.
    This application makes it possible to create a rootfs archive from
    the local redhat repository.

    Usage (called by :func:`main`)::

        with CreateRedhatRootfsApp() as app:
          return app.run() or 0
        return 1
    """

    DEFAULT_RPM_DB_PATH = pathlib.Path("/var/lib/rpm")
    """Path of the default of the directory containing the ``RPM`` database."""

    def __init__(self, *args, **kwargs):
        """`CreateRedhatRootfsApp` constructor.

        :arg args: `~.core.Application` args.
        :arg kwargs: `~.core.Application` kwargs.
        """
        super().__init__(*args, **kwargs)

        self.tmpdir = None

        self.rpm_binpath = None
        self.yum_binpath = None

    def init_parser(self) -> None:
        """Add all arguments to the application.

        See :ref:`ring-create-redhat-rootfs-usage`.
        """
        self.parser = argparse.ArgumentParser(self.name, add_help=False)

        application_group = self.parser.add_argument_group(
            "application options"
        )
        application_group.add_argument(
            "--releasepkg", default="redhat-release",
            help="Name of the release package (default: redhat-release)"
        )
        application_group.add_argument(
            "-o", "--output", dest="output_filepath", type=pathlib.Path,
            default="redhat-rootfs.tgz",
            help="Path of the output rootfs archive"
        )

        package_selection_group = self.parser.add_argument_group(
            "packages options"
        )
        package_selection_group.add_argument(
            "-I", "--include", action="append", default=[],
            help="List of packages which will be added"
        )
        package_selection_group.add_argument(
            "-X", "--exclude", action="append", default=[],
            help="List of packages which will be excluded"
        )

        self._init_archive_parser()
        self._init_postinstall_parser()

        other_group = self.parser.add_argument_group("other options")
        other_group.add_argument(
            "--cachedir", type=pathlib.Path,
            help="Path of the persistent cache directory to use "
            "to store the redhat system"
        )
        other_group.add_argument(
            "-m", "--mirror", help="Mirror to use"
        )
        other_group.add_argument(
            "--public-key", type=pathlib.Path,
            help="Path of the public key file"
        )
        other_group.add_argument(
            "-f", "--force", action="store_true", default=False,
            help="Force the execution of debootstrap even if "
            "the cache directory is not empty."
        )
        other_group.add_argument(
            "--force-overwrite", action="store_true", default=False,
            help="Overwrite the output file if it already exists "
            "(--force bring --force-overwrite)"
        )

        generic_group = self.parser.add_argument_group("generic options")
        generic_group.add_argument(
            "-d", "--debug", action="store_true", default=False,
            help="Show debug messages"
        )
        generic_group.add_argument(
            "-h", "--help", action="help",
            help="Show this help message and exit"
        )

    def _prepare_redhat_system(self) -> typing.Tuple[pathlib.Path, bool]:
        """Prepare the installation of the Redhat system.

        :returns: The path of the cache directory to use, and a
                  boolean to known if we should execute install the system.
        :raises RuntimeError: On internal error.
        :raises BuildEnvException: On critical error.
        """
        self.yum_binpath = shutil.which("yum")
        if not self.yum_binpath:
            raise exceptions.BuildEnvException(
                "Unable to find yum binary"
            )

        self.rpm_binpath = shutil.which("rpm")
        if not self.rpm_binpath:
            raise exceptions.BuildEnvException(
                "Unable to find rpm binary"
            )

        if self.args.cachedir:
            dirpath = self.args.cachedir
        elif self.tmpdir:
            dirpath = self.tmpdir
        else:
            raise RuntimeError(
                "Internal error: cachedir not given and tmpdir not created"
            )

        try:
            content = os.listdir(str(dirpath))
        except FileNotFoundError:
            pass
        else:
            if content:
                logger.debug('Cache directory "%s" already filled', dirpath)

                if not self.args.force:
                    return dirpath, False

                logger.info('Removing "%s"...', dirpath)
                try:
                    shutil.rmtree(str(dirpath))
                except OSError as exc:
                    raise exceptions.BuildEnvException(
                        'Unable to remove the existing cache '
                        'directory "{0}": {1}'.format(
                            dirpath, exc
                        )
                    )

        if not dirpath.is_dir():
            logger.info('Creating directory "%s"...', dirpath)
            try:
                dirpath.mkdir(mode=0o755, parents=True)
            except OSError as exc:
                raise exceptions.BuildEnvException(
                    'Unable to create the cache directory "{0}": {1}'.format(
                        dirpath, exc
                    )
                )

        return dirpath, True

    def _install_release_package(self, rootdirpath: pathlib.Path):
        """Install release package.

        :args rootdirpath: Path of the root directory in which we will
                             install the release package.
        :raises BuildEnvException: On error.
        """
        local_proto = "file://"
        if not self.args.mirror.startswith(local_proto):
            raise exceptions.BuildEnvException(
                'Only local mirror is supported yet'
            )

        repository_dirpath = pathlib.Path(
            self.args.mirror[len(local_proto):]
        )

        if not repository_dirpath.is_dir():
            raise exceptions.BuildEnvException(
                'Unable to find the local repository "{0}"'.format(
                    repository_dirpath
                )
            )

        try:
            releasepkg_filepath = next(repository_dirpath.glob(
                "{0}-*.rpm".format(self.args.releasepkg)
            ))
        except StopIteration:
            raise exceptions.BuildEnvException(
                'Unable to find a candidate package "{0}"'
                ' from the local repository "{1}"'.format(
                    self.args.releasepkg, repository_dirpath
                )
            )

        logger.info('Installing "%s"...', releasepkg_filepath.name)

        cmdline = [
            self.rpm_binpath,
            "--root", str(rootdirpath),
            "--dbpath", str(self.DEFAULT_RPM_DB_PATH),
            "--nodeps", "--install", "--verbose", "--hash",
            str(releasepkg_filepath)
        ]

        logger.debug("$ %s", " ".join(cmdline))
        try:
            subprocess.run(
                cmdline, shell=False, check=True,
                universal_newlines=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT
            )
        except subprocess.CalledProcessError as exc:
            for line in str(exc.stdout).splitlines():
                logger.error("%s", line)

            raise exceptions.BuildEnvException(
                'Unable to install "{0}" (exitcode: {1})'.format(
                    releasepkg_filepath, exc.returncode
                )
            )

    def _configure_repository(self, rootdirpath: pathlib.Path) -> pathlib.Path:
        """Configure the ``yum`` repository to target the given mirror.

        :args rootdirpath: Path of the root directory of the Redhat system.
        :returns: The path of the file ``scality.repo``.
        :raises BuildEnvException: On error.
        """
        yum_repos_dirpath = rootdirpath.joinpath("etc", "yum.repos.d")
        for yum_repo_filepath in yum_repos_dirpath.glob("*.repo"):
            logger.info('Removing "<root>/%s"...',
                        yum_repo_filepath.relative_to(rootdirpath))
            try:
                yum_repo_filepath.unlink()
            except OSError as exc:
                raise exceptions.BuildEnvException(
                    'Unable to remove "{0}": {1}'.format(
                        yum_repo_filepath, exc
                    )
                )

        scality_repo_filepath = yum_repos_dirpath.joinpath("scality.repo")

        logger.info('Creating "<root>/%s"...',
                    scality_repo_filepath.relative_to(rootdirpath))

        with scality_repo_filepath.open("w") as scality_repo_file:
            scality_repo_file.write(
                "[scality]\n"
                "name=Scality repository\n"
                "baseurl={0}\n".format(self.args.mirror)
            )

            if self.args.public_key:
                scality_repo_file.write(
                    "gpgcheck=1\n"
                    "gpgkey=file://{0}\n".format(
                        self.args.public_key.resolve()
                    )
                )

        return scality_repo_filepath

    def _import_public_key(self, rootdirpath: pathlib.Path) -> None:
        """Import the given public key file.

        :args rootdirpath: Path of the root directory of the Redhat system.
        :raises BuildEnvException: On error.
        """
        if not self.args.public_key:
            pass

        logger.info('Importing public key "%s"...', self.args.public_key)

        cmdline = [
            self.rpm_binpath,
            "--root", str(rootdirpath),
            "--dbpath", str(self.DEFAULT_RPM_DB_PATH),
            "--import", str(self.args.public_key)
        ]

        logger.debug("$ %s", " ".join(cmdline))
        try:
            subprocess.run(
                cmdline, shell=False, check=True,
                universal_newlines=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT
            )
        except subprocess.CalledProcessError as exc:
            for line in str(exc.stdout).splitlines():
                logger.error("%s", line)

            raise exceptions.BuildEnvException(
                'Unable to import the public key "{0}" (exitcode: {1})'.format(
                    self.args.public_key, exc.returncode
                )
            )

    @contextlib.contextmanager
    def _patch_rpmmacros(self) -> None:
        """Overwrite temporary ``dbpath`` value in ``~/.rpmmacros``.

        :raises BuildEnvException: On error.
        """
        rpmmacros_filepath = pathlib.Path("~/.rpmmacros").expanduser()

        if rpmmacros_filepath.exists():
            filesize = rpmmacros_filepath.stat().st_size
        else:
            filesize = None

        try:
            with rpmmacros_filepath.open("a+") as rpmmacros_file:
                rpmmacros_file.write(
                    "%_dbpath {0}\n"
                    "%_install_langs en_US.UTF-8\n".format(
                        self.DEFAULT_RPM_DB_PATH
                    )
                )
        except OSError as exc:
            raise exceptions.BuildEnvException(
                'Unable to modify "{0}": {1}'.format(
                    rpmmacros_filepath, exc
                )
            )

        try:
            yield
        finally:
            try:
                if filesize is not None:
                    with rpmmacros_filepath.open("a+") as rpmmacros_file:
                        rpmmacros_file.truncate(filesize)
                else:
                    rpmmacros_filepath.unlink()
            except OSError as exc:
                logger.warning('Unable to restore "%s": %s',
                               rpmmacros_filepath, exc)

    def _install_packages(self, rootdirpath: pathlib.Path) -> None:
        """Install all needed packages.

        :args rootdirpath: Path of the root directory of the Redhat system.
        :raises BuildEnvException: On error.
        """
        logger.info("Installing all needed packages...")

        cmdline = [
            self.yum_binpath,
            "--assumeyes",
            "--installroot", str(rootdirpath),
            "--setopt=tsflags=nodocs",
            "--setopt=keepcache=0",
            "install"
        ]

        for pkgname in self.args.exclude:
            cmdline += ["-x", pkgname]

        cmdline += self.args.include

        logger.debug("$ %s", " ".join(cmdline))
        try:
            subprocess.run(cmdline, shell=False, check=True)
        except subprocess.CalledProcessError as exc:
            raise exceptions.BuildEnvException(
                'Unable to install packages (exitcode: {0})'.format(
                    exc.returncode
                )
            )

    def _rebuild_rpm_database(self, rootdirpath: pathlib.Path) -> None:
        """Rebuild ``RPM`` database.

        The version of ``rpm`` of the host can be different of the
        version of ``rpm`` of the target system.
        The ``rpm`` database files must be rebuilt.

        :args rootdirpath: Path of the root directory of the Redhat system.
        :raises BuildEnvException: On error.
        """
        rpm_db_dirpath = rootdirpath.joinpath(
            self.DEFAULT_RPM_DB_PATH.relative_to("/")
        )

        for filepath in rpm_db_dirpath.iterdir():
            if filepath.name == "Packages":
                continue

            logger.info('Removing "<root>/%s"...',
                        filepath.relative_to(rootdirpath))

            try:
                filepath.unlink()
            except OSError as exc:
                raise exceptions.BuildEnvException(
                    'Unable to remove "{0}": {1}'.format(
                        filepath, exc
                    )
                )

        logger.info("Rebuildding rpm database...")

        def preexec_fn():
            os.chroot(str(rootdirpath))
            os.chdir("/")

        try:
            subprocess.run([
                "rpm", "--rebuilddb"
            ], preexec_fn=preexec_fn, shell=False, check=True)
        except subprocess.CalledProcessError as exc:
            raise exceptions.BuildEnvException(
                'Unable to rebuild rpm database (exitcode: {0})'.format(
                    exc.returncode
                )
            )

    def _remove_repository(self, rootdirpath: pathlib.Path,
                           scality_repo_filepath: pathlib.Path) -> None:
        """Remove the local repository definition and the public key imported.

        :args rootdirpath: Path of the root directory of the Redhat system.
        :raises BuildEnvException: On error.
        """
        cmdline = [
            self.rpm_binpath,
            "--root", str(rootdirpath),
            "--dbpath", str(self.DEFAULT_RPM_DB_PATH),
            "--query", "gpg-pubkey"
        ]

        logger.debug("$ %s", " ".join(cmdline))
        try:
            result = subprocess.run(
                cmdline, shell=False, check=True,
                universal_newlines=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT
            )
        except subprocess.CalledProcessError as exc:
            for line in str(exc.stdout).splitlines():
                logger.error("%s", line)

            raise exceptions.BuildEnvException(
                'Unable to list of gpg public key packages'
                ' (exitcode: {1})'.format(exc.returncode)
            )

        gpg_pubkey_pkgnames = result.stdout.splitlines()
        if gpg_pubkey_pkgnames:
            logger.info("Removing GPG public key packages (%s)...",
                        ", ".join(gpg_pubkey_pkgnames))

            cmdline = [
                self.rpm_binpath,
                "--root", str(rootdirpath),
                "--dbpath", str(self.DEFAULT_RPM_DB_PATH),
                "--erase"
            ] + gpg_pubkey_pkgnames

            logger.debug("$ %s", " ".join(cmdline))
            try:
                subprocess.run(cmdline, shell=False, check=True)
            except subprocess.CalledProcessError as exc:
                raise exceptions.BuildEnvException(
                    'Unable to remove gpg public key packages'
                    ' (exitcode: {0})'.format(exc.returncode)
                )

        try:
            scality_repo_filepath.unlink()
        except OSError as exc:
            raise exceptions.BuildEnvException(
                'Unable to remove "{0}": {1}'.format(
                    scality_repo_filepath, exc
                )
            )

    def _install_redhat_system(self) -> pathlib.Path:
        """Install the Redhat system.

        Performs:

        * Clean old cache directory if needed (see
          :meth:`_prepare_redhat_system`).
        * Install release package (see
          :meth:`_install_release_package`).
        * Configure the local repository (see
          :meth:`_configure_repository`).
        * Import public key if given (see :meth:`_import_public_key`).
        * Install all needed packages (see :meth:`_install_packages`).
        * Rebuild RPM database (see :meth:`_rebuild_rpm_database`).
        * Remove the local repository and the public key (see
          :meth:`_remove_repository`).
        * Execute postinstall script if given (see
          :meth:`~.PostinstallAppMixin._execute_postinstall_script`).

        :raises BuildEnvException: On error.
        """
        dirpath, do_run = self._prepare_redhat_system()
        if not do_run:
            return dirpath

        try:
            self._install_release_package(dirpath)
            scality_repo_filepath = self._configure_repository(dirpath)
            self._import_public_key(dirpath)
            with self._patch_rpmmacros():
                self._install_packages(dirpath)
            self._remove_repository(dirpath, scality_repo_filepath)
            self._rebuild_rpm_database(dirpath)

            self._execute_postinstall_script(dirpath)

            return dirpath
        except BaseException:
            if self.args.cachedir:
                try:
                    shutil.rmtree(str(self.args.cachedir))
                except OSError as exc:
                    logger.warning(
                        'Unable to remove the existing cache '
                        'directory "%s": %s', self.args.cachedir, exc
                    )
            raise

    def run(self) -> typing.Union[None, int]:
        """Main function of the application.

        :returns: Application exit code
        :raises BuildEnvException: On error.
        """
        if os.getuid() != 0:
            raise exceptions.BuildEnvException(
                "This application must be executed as root"
            )

        if self.args.force:
            self.args.force_overwrite = True

        if self.args.cachedir is None:
            self.tmpdir = pathlib.Path(
                tempfile.mkdtemp(prefix="get-deps-", suffix=".d")
            )
            logger.debug("Temporary directory: %s", self.tmpdir)

        dirpath = self._install_redhat_system()
        self._create_tar_archive(
            dirpath, self.args.output_filepath,
            force=self.args.force_overwrite
        )

        return 0

    def clean(self):
        """Remove the temporary directory."""
        if not self.tmpdir:
            return

        try:
            shutil.rmtree(self.tmpdir)
        except OSError as exc:
            logger.warning(
                'Unable to remove temporary directory "%s": %s',
                self.tmpdir, exc
            )


def main() -> int:
    """Main function called by :ref:`ring-create-redhat-rootfs`.

    Instantiate a `CreateRedhatRootfsApp` object and run it.

    See `~.core.Application` for more details.

    :returns 0: On success
    :returns != 0: On failure
    """
    with CreateRedhatRootfsApp() as app:
        return app.run() or 0
    return 1
