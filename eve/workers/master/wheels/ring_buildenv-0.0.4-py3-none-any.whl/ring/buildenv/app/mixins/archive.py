"""Mixin class to create archive file from an application.

Contents:

* `ArchiveAppMixin`: Mixin class to provide
  :meth:`~ArchiveAppMixin._init_archive_parser` and
  :meth:`~ArchiveAppMixin._create_tar_archive` methods.
"""
import logging
import pathlib
import tarfile

import ring.buildenv.exceptions as exceptions

logger = logging.getLogger(__name__)


class ArchiveAppMixin(object):
    def _init_archive_parser(self) -> None:
        """Add archive options to the parser."""
        archive_group = self.parser.add_argument_group("archive options")
        archive_group.add_argument(
            "--format", default="auto",
            choices=["auto", "gzip", "bzip2", "lzma", "none"],
            help="Compression format of the archive"
        )
        archive_group.add_argument(
            "--gzip", action="store_const", const="gzip", dest="format",
            help="Create gzip archive file (equivalent of --format=gzip)"
        )
        archive_group.add_argument(
            "--bzip2", action="store_const", const="bzip2", dest="format",
            help="Create bzip2 archive file (equivalent of --format=bzip2)"
        )
        archive_group.add_argument(
            "--lzma", action="store_const", const="lzma", dest="format",
            help="Create lzma archive file (equivalent of --format=lzma)"
        )

    def _create_tar_archive(self, dirpath: pathlib.Path,
                            output_filepath: pathlib.Path,
                            force: bool=False):
        """Create the tar archive of the system.

        :args dirpath: Path of the directory which contain the system
        :args output_filepath: Path of the file to write
        :args force: Force overwrite existing file
        :raises BuildEnvException: On error
        """
        if output_filepath.exists() and not force:
            raise exceptions.BuildEnvException(
                'File "{0}" already exists'.format(output_filepath)
            )

        if self.args.format == 'auto':
            ext = ''.join(output_filepath.suffixes)
            if ext in ['.tar.gz', '.tgz']:
                self.args.format = 'gzip'
            elif ext in ['.tar.bz2', '.tbz']:
                self.args.format = 'bzip2'
            elif ext in ['.tar.xz', '.txz']:
                self.args.format = 'lzma'
            else:
                self.args.format = None

        fmt_to_tarfile_fmt = {
            "gzip": "gz",
            "bzip2": "bz2",
            "lzma": "xz"
        }
        fmt = fmt_to_tarfile_fmt.get(self.args.format, "")

        if not output_filepath.parent.is_dir():
            logger.info('Creating directory "%s"...', output_filepath.parent)
            try:
                output_filepath.parent.mkdir(mode=0o755, parents=True)
            except OSError as exc:
                raise exceptions.BuildEnvException(
                    'Unable to create the output directory "{0}": {1}'.format(
                        output_filepath.parent, exc
                    )
                )

        logger.info('Creating rootfs archive "%s" (%s) from "%s"...',
                    output_filepath, self.args.format or "none", dirpath)

        try:
            with tarfile.open(str(output_filepath),
                              'w:{0}'.format(fmt)) as archive:
                archive.add(str(dirpath), arcname="", recursive=True)
        except tarfile.TarError as exc:
            raise exceptions.BuildEnvException(
                "Unable to create the rootfs archive: {0}".format(exc)
            )
