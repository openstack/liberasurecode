import sys

import ring.buildenv.app.env as app


if sys.argv[0].endswith("__main__.py"):
    sys.argv[0] = "python -m {0}".format(app.__name__)

app.main.main()
