"""Core of the :ref:`ring-create-debian-rootfs` application.

This application create a rootfs archive of debian distribution from
the local repository created by :ref:`ring-create-debian-repository`.

Contents:

* `CreateDebianRootfsApp`: Application class
* `main`: Main function called by :ref:`ring-create-debian-rootfs`
"""

import argparse
import logging
import os
import pathlib
import shutil
import subprocess
import tempfile
import typing

import ring.buildenv.app.core as app_core
import ring.buildenv.app.mixins as mixins
import ring.buildenv.exceptions as exceptions

logger = logging.getLogger(__name__)


class CreateDebianRootfsApp(mixins.ArchiveAppMixin,
                            mixins.PostinstallAppMixin,
                            app_core.Application):
    """`~.core.Application` class.

    This class is the core of the application :ref:`ring-create-debian-rootfs`.
    This application makes it possible to create a rootfs archive from
    the local debian repository.

    Usage (called by :func:`main`)::

        with CreateDebianRootfsApp() as app:
          return app.run() or 0
        return 1
    """
    def __init__(self, *args, **kwargs):
        """`CreateDebianRootfsApp` constructor.

        :arg args: `~.core.Application` args.
        :arg kwargs: `~.core.Application` kwargs.
        """
        super().__init__(*args, **kwargs)

        self.tmpdir = None

    def init_parser(self) -> None:
        """Add all arguments to the application.

        See :ref:`ring-create-debian-rootfs-usage`.
        """
        self.parser = argparse.ArgumentParser(self.name, add_help=False)

        application_group = self.parser.add_argument_group(
            "application options"
        )
        application_group.add_argument(
            "-s", "--suite", required=True,
            help="Codename (eg, sid, trusty) or "
            "symbolic name (eg, unstable, stable) of the debian distribution"
        )
        application_group.add_argument(
            "-a", "--arch", required=True, default="amd64",
            help="Architecture of the debian distribution"
        )
        application_group.add_argument(
            "-o", "--output", dest="output_filepath", type=pathlib.Path,
            default="debian-rootfs.tgz",
            help="Path of the output rootfs archive"
        )

        package_selection_group = self.parser.add_argument_group(
            "packages options"
        )
        package_selection_group.add_argument(
            "-I", "--include", action="append", default=[],
            help="List of packages which will be added"
        )
        package_selection_group.add_argument(
            "-X", "--exclude", action="append", default=[],
            help="List of packages which will be excluded"
        )

        self._init_archive_parser()
        self._init_postinstall_parser()

        other_group = self.parser.add_argument_group("other options")
        other_group.add_argument(
            "--cachedir", type=pathlib.Path,
            help="Path of the persistent cache directory to use "
            "to store the debian system"
        )
        other_group.add_argument(
            "-m", "--mirror", help="Mirror to use"
        )
        other_group.add_argument(
            "--public-key", type=pathlib.Path,
            help="Path of the public key file"
        )
        other_group.add_argument(
            "-f", "--force", action="store_true", default=False,
            help="Force the execution of debootstrap even if "
            "the cache directory is not empty."
        )
        other_group.add_argument(
            "--force-overwrite", action="store_true", default=False,
            help="Overwrite the output file if it already exists "
            "(--force bring --force-overwrite)"
        )

        generic_group = self.parser.add_argument_group("generic options")
        generic_group.add_argument(
            "-d", "--debug", action="store_true", default=False,
            help="Show debug messages"
        )
        generic_group.add_argument(
            "-h", "--help", action="help",
            help="Show this help message and exit"
        )

    def _prepare_debootstrap(self) -> typing.Tuple[str, pathlib.Path, bool]:
        """Prepare the ressources for the execution of ``debootstrap``.

        Create the cache directory to store the Debian system and
        check if ``debootstrap`` is available.

        :returns: The path of ``debootstrap`` binary and the path of
          the cache directory to use, and a boolean to known if we
          should execute ``debootstrap``.
        :raises RuntimeError: On internal error.
        :raises BuildEnvException: On critical error.
        """
        debootstrap_binpath = shutil.which("debootstrap")
        if not debootstrap_binpath:
            raise exceptions.BuildEnvException("debootstrap is needed")

        logger.debug("Path of debootstrap: %s", debootstrap_binpath)

        if self.args.cachedir:
            dirpath = self.args.cachedir
        elif self.tmpdir:
            dirpath = self.tmpdir
        else:
            raise RuntimeError(
                "Internal error: cachedir not given and tmpdir not created"
            )

        try:
            content = os.listdir(str(dirpath))
        except FileNotFoundError:
            pass
        else:
            if content:
                logger.debug('Cache directory "%s" already filled', dirpath)

                if not self.args.force:
                    return debootstrap_binpath, dirpath, False

                logger.info('Removing "%s"...', dirpath)
                try:
                    shutil.rmtree(str(dirpath))
                except OSError as exc:
                    raise exceptions.BuildEnvException(
                        'Unable to remove the existing cache '
                        'directory "{0}": {1}'.format(
                            dirpath, exc
                        )
                    )

        if not dirpath.is_dir():
            logger.info('Creating directory "%s"...', dirpath)
            try:
                dirpath.mkdir(mode=0o755, parents=True)
            except OSError as exc:
                raise exceptions.BuildEnvException(
                    'Unable to create the cache directory "{0}": {1}'.format(
                        dirpath, exc
                    )
                )

        return debootstrap_binpath, dirpath, True

    def _run_debootstrap(self):
        """Execute ``debootstrap`` to bootstraps the basic Debian system.

        :returns: Path of the directory which contain the Debian system
        :raises BuildEnvException: On critical error
        """
        debootstrap_binpath, dirpath, do_run = self._prepare_debootstrap()
        if not do_run:
            return dirpath

        args = [
            debootstrap_binpath,
            "--components", "main",
            "--variant", "minbase",
            "--force-check-gpg"
        ]

        if self.args.arch:
            args += ["--arch", self.args.arch]

        if self.args.include:
            args += ["--include", ",".join(self.args.include)]
        if self.args.exclude:
            args += ["--exclude", ",".join(self.args.exclude)]

        if self.args.public_key:
            args += ["--keyring", self._create_keyring(self.args.public_key)]

        if self.args.debug:
            args += ["--verbose"]

        args += [self.args.suite, str(dirpath)]

        if self.args.mirror:
            args += [self.args.mirror]

        logger.info("Bootstrapping the Debian system (%s)...", self.args.suite)
        logger.debug('Execution of "%s"...', " ".join(args))

        result = subprocess.run(args, shell=False)
        if result.returncode != 0:
            self._try_clear_persistent_cache(dirpath)

            raise exceptions.BuildEnvException(
                "Unable to bootstrap the Debian system"
            )

        return dirpath

    def _create_keyring(self, public_key_filepath: pathlib.Path):
        """Create a temporary keyring with the given public key.

        :args publick_key_filepath: Path of the public key file
        :returns: The path of the temporary keyring created
        """
        tmpfile, tmpfilepath = tempfile.mkstemp(
            prefix="ring-buildenv-keyring-",
            suffix=".gpg",
            dir=self.tmpdir
        )

        logger.info('Importing "%s" into keyring "%s"...',
                    public_key_filepath, tmpfilepath)

        result = subprocess.run([
            "gpg", "--no-default-keyring", "--keyring", tmpfilepath,
            "--import", str(public_key_filepath)
        ], shell=False, stderr=subprocess.DEVNULL)

        os.close(tmpfile)

        if result.returncode != 0:
            raise exceptions.BuildEnvException(
                "Unable to import the public "
                "key file {0}".format(public_key_filepath)
            )

        return tmpfilepath

    def _try_clear_persistent_cache(self, dirpath: pathlib.Path) -> None:
        """Try to clear existing cache directory.

        Do nothing if the cache directory used is a temporary
        directory (when ``--cachedir`` is not used).

        :args dirpath: Path of the directory used as cache
        """
        if not self.args.cachedir:
            return

        assert dirpath == self.args.cachedir

        try:
            shutil.rmtree(self.args.cachedir)
        except OSError as exc:
            logger.warning(
                'Unable to remove the existing cache '
                'directory "%s": %s', self.args.cachedir, exc
            )

    def run(self) -> typing.Union[None, int]:
        """Main function of the application.

        This function do:

        * Check if the application is run as root
        * Create a temporary directory to store the Debian system
          if no cachedir is given.
        * Run ``debootstrap`` to bootstrap the Debian system.
        * Create the tar archive
        """
        if os.getuid() != 0:
            raise exceptions.BuildEnvException(
                "This application must be executed as root"
            )

        if self.args.force:
            self.args.force_overwrite = True

        if self.args.cachedir is None:
            self.tmpdir = pathlib.Path(
                tempfile.mkdtemp(prefix="get-deps-", suffix=".d")
            )
            logger.debug("Temporary directory: %s", self.tmpdir)

        dirpath = self._run_debootstrap()
        self._execute_postinstall_script(dirpath)

        self._create_tar_archive(
            dirpath, self.args.output_filepath,
            force=self.args.force_overwrite
        )

    def clean(self):
        """Remove the temporary directory."""
        if not self.tmpdir:
            return

        try:
            shutil.rmtree(self.tmpdir)
        except OSError as exc:
            logger.warning(
                'Unable to remove temporary directory "%s": %s',
                self.tmpdir, exc
            )


def main() -> int:
    """Main function called by :ref:`ring-create-debian-rootfs`.

    Instantiate a `CreateDebianRootfsApp` object and run it.

    See `~.core.Application` for more details.

    :returns 0: On success
    :returns != 0: On failure
    """
    with CreateDebianRootfsApp() as app:
        return app.run() or 0
    return 1
