"""Core of the :ref:`ring-create-docker-image` application.

This application create a docker image from the local repository
created by :ref:`ring-create-debian-repository` and from the rootfs
archive created by :ref:`ring-create-debian-rootfs`.

Contents:

* `CreateDockerImageApp`: Application class
* `main`: Main function called by :ref:`ring-create-docker-image`
"""

import argparse
import collections
import io
import json
import logging
import os
import pathlib
import re
import tarfile
import tempfile
import typing

import docker

import ring.buildenv.app.core as app_core
import ring.buildenv.exceptions as exceptions


logger = logging.getLogger(__name__)

_ExtraFile = collections.namedtuple("_ExtraFile", [
    "srcfilepath", "ctxfilepath"
])


class CreateDockerImageApp(app_core.Application):
    """`~.core.Application` class.

    This class is the core of the application :ref:`ring-create-docker-image`.
    This application create a docker image from the local repository
    created by :ref:`ring-create-debian-repository` and from the rootfs
    archive created by :ref:`ring-create-debian-rootfs`.

    Usage (called by :func:`main`)::

        with CreateDockerImageApp() as app:
          return app.run() or 0
        return 1
    """

    dockerfile_name = "Dockerfile"
    """Name of the Dockerfile inside the Docker context."""

    def __init__(self, *args, **kwargs):
        """`CreateDockerImageApp` constructor.

        :arg args: `~.core.Application` args.
        :arg kwargs: `~.core.Application` kwargs.
        """
        super().__init__(*args, **kwargs)

    def init_parser(self) -> None:
        """Add all arguments to the application.

        See :ref:`ring-create-docker-image-usage`.
        """
        self.parser = argparse.ArgumentParser(
            self.name, add_help=False,
            formatter_class=argparse.RawDescriptionHelpFormatter,
            description="""
This application use several environment variables:
* DOCKER_HOST:       The URL to the Docker host.
* DOCKER_TLS_VERIFY: Verify the host against a CA certificate.
* DOCKER_CERT_PATH:  A path to a directory containing TLS certificates
                      to use when connecting to the Docker host."""
        )

        application_group = self.parser.add_argument_group(
            "application options"
        )
        application_group.add_argument(
            "-f", "--dockerfile", metavar="DOCKERFILE",
            dest="docker_filepath", type=pathlib.Path, required=True,
            help="Path of the Dockerfile to use"
        )

        def extra_file_in_docker_ctx(value):
            if '=' in value:
                srcfilepath, ctxfilepath = value.split('=', 1)
            else:
                srcfilepath = value
                ctxfilepath = os.path.basename(srcfilepath)

            return _ExtraFile(pathlib.Path(srcfilepath),
                              pathlib.Path(ctxfilepath))

        application_group.add_argument(
            "-I", "--include", action="append", type=extra_file_in_docker_ctx,
            metavar="PATH[=PATH_IN_CTX]", default=[], dest="extra_files",
            help="Add an additionnal file in the docker context."
            "Can be passed multiple times."
        )

        application_group.add_argument(
            "--print-image-id-to-fd", dest="output_image_id_fd",
            type=int, metavar="FD",
            help="File descriptor to print the if of the image buid"
        )

        docker_group = self.parser.add_argument_group("docker options")
        docker_group.add_argument(
            "-t", "--tag", action="append", default=[], dest="tags",
            help="Tag(s) of the image to deploy"
        )
        docker_group.add_argument(
            "--gzip", action="store_true", default=False,
            help="Use a compressed gzip docker context"
        )
        docker_group.add_argument(
            "--version", default="auto",
            help="The version of the API to use. "
            "Set to auto to automatically detect the server’s version"
        )
        docker_group.add_argument(
            "--timeout",
            help="Default timeout for Docker API calls, in seconds."
        )
        docker_group.add_argument(
            "--from", dest="from_image_id", metavar="IMAGE_ID",
            help="Override FROM instruction in the "
            "dockerfile to use the given image id"
        )

        generic_group = self.parser.add_argument_group("generic options")
        generic_group.add_argument(
            "-d", "--debug", action="store_true", default=False,
            help="Show debug messages"
        )
        generic_group.add_argument(
            "-h", "--help", action="help",
            help="Show this help message and exit"
        )

    @staticmethod
    def _iter_build_stream(build_stream):
        """Parse log from docker build.

        :yield: Each stream data
        """
        for raw_data in build_stream:
            try:
                data = json.loads(raw_data.decode("utf-8"))
            except json.JSONDecodeError as exc:
                logger.warning("Unable to parse the json chunk '%s'"
                               " from docker: %s", raw_data, exc)
                continue

            if not isinstance(data, dict):
                logger.warning("Invalid object received from docker: %s", data)
                continue

            if not data:
                continue

            if "stream" in data:
                yield data["stream"].strip()
            elif "progress" in data:
                logger.info("  %s %s", data["status"], data["progress"])
            elif "error" in data:
                errordetail = data.get("errorDetail", {})
                error_message = errordetail.get("message", data["error"])
                raise exceptions.BuildEnvException(
                    "Unable to build Docker image: {0}".format(error_message)
                )
            else:
                logger.warning(
                    'Object "%s" from docker not supported yet', data
                )

    def run(self) -> typing.Union[None, int]:
        """Main function of the application."""
        docker_client = docker.from_env(
            version=self.args.version,
            timeout=self.args.timeout
        )

        try:
            docker_client.ping()
        except docker.errors.APIError as exc:
            raise exceptions.BuildEnvException(
                "The Docker server isn't responding: {0}".format(exc)
            )
        else:
            logger.info("Docker server is responsive.")

        logger.info("Creating Docker context...")
        dockerctx = self._create_docker_context()

        logger.info("Building Docker image...")
        build_stream = docker_client.api.build(
            fileobj=dockerctx,
            custom_context=True,
            encoding="gzip" if self.args.gzip else None,
            tag=self.args.tags.pop() if self.args.tags else None,
            dockerfile=self.dockerfile_name,
            quiet=False,
            rm=True,
            forcerm=True,
        )

        success_build_regexp = re.compile(
            r'\s*Successfully built (?P<image_id>[0-9a-f]+).*'
        )
        docker_image_id = None

        for msg in self._iter_build_stream(build_stream):
            m = success_build_regexp.match(msg)
            if m:
                docker_image_id = m.group("image_id")

            logger.info("  %s", msg)

        dockerctx.close()

        if not docker_image_id:
            raise exceptions.BuildEnvException(
                "Unable to get the docker image id"
            )

        docker_image = docker_client.images.get(docker_image_id)

        for extra_tag in self.args.tags:
            if ':' in extra_tag:
                repository, tag = extra_tag.split(':', 1)
            else:
                repository = extra_tag
                tag = 'latest'

            logger.info("Adding extra tag %s:%s to image %s...",
                        repository, tag, docker_image.id)
            docker_image.tag(repository, tag)

        self._print_output_image_id(docker_image)

    def _print_output_image_id(self, docker_image):
        """Print the ID of the docker image build if needed.

        :args docker_image: Docker image to print the ID
        """
        if self.args.output_image_id_fd is None:
            return

        m = re.match(r"sha256:(?P<image_id>[0-9a-f]{64})", docker_image.id)
        if not m:
            raise exceptions.BuildEnvException(
                'Image ID "{0}" not supported'.format(docker_image.id)
            )

        output_image_id = m.group("image_id")

        with io.FileIO(self.args.output_image_id_fd, "w") as output_file:
            output_file.write(
                "{0}\n".format(output_image_id).encode("utf-8")
            )

    @staticmethod
    def _add_elem_in_tar_archive(tarfileobj: tarfile.TarFile,
                                 path: typing.Union[pathlib.Path, str],
                                 arcname: typing.Union[
                                     pathlib.Path, str, None
                                 ]=None) -> None:
        """Add a file or directory in the given `tarfile.TarFile` object.

        This function takes care of the error handlings around the
        function :meth:`tarfile.TarFile.add`.

        :args tarfile: tar archive which will contain the given file
                or directory
        :args path: Path of the file or the directory to add to the tar archive
        :args arcname: Path of the given file or directory inside the
                tar archive
        :raises BuildEnvException: On error
        """
        if isinstance(path, pathlib.Path):
            path = str(path)

        if arcname is not None and \
           isinstance(arcname, pathlib.Path):
            arcname = str(arcname)

        if not os.path.exists(path):
            raise exceptions.BuildEnvException(
                'Unable to find the file or directory "{0}"'.format(
                    path
                )
            )

        if os.path.isfile(path):
            elem_type = "file"
        elif os.path.isdir(path):
            elem_type = "directory"
        else:
            elem_type = None

        elem_type_str = ' {0}'.format(elem_type) if elem_type else ''
        arcname_str = ' -> "{0}"'.format(arcname) if arcname else ''

        logger.info('Adding%s "%s"%s...', elem_type_str, path, arcname_str)

        try:
            tarfileobj.add(path, arcname=arcname, recursive=True)
        except FileNotFoundError as exc:
            error = exc.strerror
        except tarfile.TarError as exc:
            error = str(exc)
        else:
            error = None

        if error:
            raise exceptions.BuildEnvException(
                'Unable to add{0} "{1}"{2}'
                ' in the docker context archive: {3}'.format(
                    ' the{0}'.format(elem_type_str) if elem_type_str else '',
                    path, arcname_str, error
                )
            )

    def _create_docker_context(self) -> tempfile.NamedTemporaryFile:
        """Create the docker context.

        This method create the complete Docker context archive to send
        to the Docker host. It will add the Dockerfile and all extra
        file given to :ref:`ring-create-docker-image` application.

        :raises BuildEnvException: On error
        :returns: The temporary file which contain the Docker context
        """
        fileobj = tempfile.NamedTemporaryFile(
            prefix="ring-buildenv-dockerctx-",
            suffix=".tar{0}".format(
                ".gz" if self.args.gzip else ""
            )
        )

        mode = "w"
        if self.args.gzip:
            mode += "|gz"

        dockerctx = tarfile.open(mode=mode, fileobj=fileobj)

        self._add_dockerfile_in_ctx(dockerctx)

        for extra_file in self.args.extra_files:
            self._add_elem_in_tar_archive(
                dockerctx,
                extra_file.srcfilepath,
                extra_file.ctxfilepath
            )

        try:
            dockerctx.close()
        except tarfile.TarError as exc:
            raise exceptions.BuildEnvException(
                'Unable to finalize the docker context'
                ' archive: {0}'.format(exc)
            )

        fileobj.seek(0)

        return fileobj

    def _add_dockerfile_in_ctx(self, dockerctx) -> None:
        """Add the given Dockerfile in the Docker context.

        Create a temporary file if needed to replace on the fly the
        FROM argument.

        :args dockerctx: Docker context archive
        """
        dockerfile_modified = False
        if self.args.from_image_id:
            from_regexp = re.compile(r"^\s*FROM\s+(?P<from_image_id>\S+)")
            try:
                with self.args.docker_filepath.open("r") as dockerfile:
                    content = ''
                    for line in dockerfile:
                        m = from_regexp.match(line)
                        if m:
                            from_image_id = m.group('from_image_id')
                            if from_image_id != self.args.from_image_id:
                                line = 'FROM {0}'.format(
                                    self.args.from_image_id
                                )
                                dockerfile_modified = True
                        content += line
            except OSError as exc:
                raise exceptions.BuildEnvException(
                    'Unable to read the Dockerfile "{0}": {1}'.format(
                        self.args.docker_filepath, exc
                    )
                )
        else:
            content = None

        if dockerfile_modified:
            tmpfile = tempfile.NamedTemporaryFile(
                prefix="ring-buildenv-dockerfile-"
            )

            with tmpfile:
                tmpfile.write(content.encode("utf-8"))
                tmpfile.flush()

                self._add_elem_in_tar_archive(
                    dockerctx, tmpfile.name,
                    arcname=self.dockerfile_name
                )
        else:
            self._add_elem_in_tar_archive(
                dockerctx, self.args.docker_filepath,
                arcname=self.dockerfile_name
            )


def main() -> int:
    """Main function called by :ref:`ring-create-docker-image`.

    Instantiate a `CreateDockerImageApp` object and run it.

    See `~.core.Application` for more details.

    :returns 0: On success
    :returns != 0: On failure
    """
    with CreateDockerImageApp() as app:
        return app.run() or 0
    return 1
