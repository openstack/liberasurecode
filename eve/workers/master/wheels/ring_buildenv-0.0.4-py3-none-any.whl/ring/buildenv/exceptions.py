"""Exceptions raised by ``ring.buildenv``."""

import subprocess


class BuildEnvException(Exception):
    """Base exception for all ``ring.buildenv`` applications."""


class ShellCommandError(subprocess.CalledProcessError):
    """Raised when the spawned process exit in error."""
